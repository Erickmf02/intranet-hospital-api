import React, { StrictMode } from 'react'
import "./main.css"
import ReactDOM from 'react-dom/client'
import "bootstrap/dist/css/bootstrap.min.css"
import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";
import 'animate.css';
import Login from './pages/login/Login.jsx'
import PanelAdmin from './pages/panelAdmin/panelAdmin.jsx'
import VerProtocolo from './pages/verProtocolo/verProtocolo.jsx';
import Home from "./pages/home/home.jsx"
import Perfil from "./pages/perfilDeUsuario/Perfil.jsx"
import User from "./pages/user/user.jsx"
import Lista from "./pages/perfilDeUsuario/lista.jsx"
import Carpeta from './pages/carpeta/carpeta.jsx';
import CarpetaArchivos from './pages/carpetaArchivos/carpetaArchivos.jsx';
import Archivos from "./pages/home/archivos.jsx"
import Hospital from "./pages/home/Hospital.jsx"
const router = createBrowserRouter([
  {
    path: "/login",
    element: <Login></Login>
  },
  {
    path: "/administracion",
    element: <PanelAdmin></PanelAdmin>
  },
  {
    path: "/protocolo/:id",
    element: <VerProtocolo></VerProtocolo>
  },
  {
    path: "/",
    element: <Home></Home>
  },
  {
    path: "/crear-usuario",
    element: <Perfil></Perfil>
  },
  {
    path: "/usuario/:id",
    element: <User></User>
  },
  {
    path: "/lista",
    element: <Lista></Lista>
  },
  {
    path: "/carpeta/:id",
    element: <Carpeta></Carpeta>
  },
  {
    path: "/hospital",
    element: <Hospital></Hospital>
  },
  {
    path: "/archivos",
    element: <Archivos></Archivos>
  },
  {
    path: "/archivos2",
    element: <CarpetaArchivos></CarpetaArchivos>
  }
]);

ReactDOM.createRoot(document.getElementById('root')).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>
)
