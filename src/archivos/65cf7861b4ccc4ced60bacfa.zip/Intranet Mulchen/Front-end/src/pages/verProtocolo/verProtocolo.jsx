import "../panelAdmin/panelAdmin.css";
import { useState, createContext, useEffect} from "react";
import { useNavigate, useParams } from 'react-router-dom';
import axios from "axios";
import {IP, PUERTO_API} from "../../constantes.js";
//importar componentes
import ModalEliminarProtocoloItem from "../../components/verProtocolo/modalEliminarProtocoloItem.jsx";
import ModalEditarProtocolo from "../../components/verProtocolo/modalEditarProtocolo.jsx";
import ModalEliminarProtocolo from "../../components/verProtocolo/modalEliminarProtocolo.jsx";
import ModalActualizarProtocoloItem from "../../components/verProtocolo/modalActualizarProtocoloItem.jsx";
import DragContainer from "../../components/verProtocolo/dragContainer.jsx";
import Navbar from "../../components/navbar.jsx";
import imagenDoctores from "./conseguir-un-puesto-de-trabajo-como-enfermera 3.jpg"
import { obtenerSesion, tieneTokenEnFecha } from "../../utils.js";

export const ContextoItemAEliminar = createContext();

export const ContextoItems = createContext();
export const ContextoProtocolo = createContext();
export const ContextoProtocoloItemAActualizar = createContext();

function VerProtocolo(){
    const navigate = useNavigate();
    const { id } = useParams();
    const [cargando, setCargando] = useState(true);
    const [protocolo, setProtocolo] = useState(null);
    const [items, setItems] = useState([]);

    const estadoProtocolo = {
        protocolo,
        setProtocolo
    }
    const estadoItems = {
        items,
        setItems,
    }
    

    useEffect(function(){
        async function llamarDatos() {
            try {
                const response = await axios.get(`http://${IP}:${PUERTO_API}/protocolo/${id}`);
                const protocolo = response.data;
                //eliminar
                console.log(protocolo)
                
                setProtocolo(protocolo);

                const response2 = await axios.get(`http://${IP}:${PUERTO_API}/protocolo_item/${id}/protocolo`);

                const itemsOrdenados = response2.data.sort((a, b) => a.posicion - b.posicion);
                setItems(itemsOrdenados);
                setCargando(false);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        }
    
        llamarDatos();
    }, [])

    //Item a eliminar para ModalEliminarProtocoloItem
    const [itemAEliminar, setItemAEliminar] = useState(null);
    const estadoItemAEliminar = {
        itemAEliminar,
        setItemAEliminar
    }

    useEffect(()=>{
        if(!tieneTokenEnFecha()){
            navigate("/login")
            return;
        }
    }, [])

    //actualizar protocolo item
    const [protocoloItemAActualizar, setProtocoloItemAActualizar] = useState(null);
    const estadoProtocoloItemAActualizar = {
        protocoloItemAActualizar,
        setProtocoloItemAActualizar
    }

    return (
        <div>
            <Navbar></Navbar>
            { !cargando ?
            <ContextoProtocolo.Provider value={estadoProtocolo}>
                <ContextoItems.Provider value={estadoItems}>
                    <ContextoItemAEliminar.Provider value={estadoItemAEliminar}>
                        <ContextoProtocoloItemAActualizar.Provider value={estadoProtocoloItemAActualizar}>
                                <div className="container-fluid">
                                    <div className="row">
                                        <div className="col-12">
                                            <div className="row">
                                                <div className="col-12 p-0">
                                                    <img style={{height: "275px", width: "100%", objectFit: "cover"}} src={imagenDoctores} alt="" />
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-12">
                                            <div className="row p-2 ho_bg_white" style={{backgroundColor: "white"}}>
                                                <div className="col-12 col-md-auto mb-2 mb-md-0">
                                                    <div className="row flex-column">
                                                        <div className="col-12 col-md-auto d-flex justify-content-center justify-content-md-start">
                                                            <h1 className=" ho_font_poppins m-0 ho_fs_36 lh-1 text-center ho_color_blue">
                                                                {protocolo.nombre}
                                                            </h1>
                                                        </div>
                                                        <div className="col-12 col-md-auto d-flex justify-content-center justify-content-md-start">
                                                            <h1 className="m-0 ho_fs_24 text-center">Protocolo {protocolo.abreviacion}</h1>
                                                        </div>
                                                    </div>
                                                </div>
                                                    <div className="col-12 col-md-auto d-flex justify-content-center justify-content-md-start align-items-center">
                                                        <button className="btn btn-primary ho_bg_blue ho_font_poppins" data-bs-toggle="modal" data-bs-target="#editarProtocolo">Editar protocolo</button>
                                                        <ModalEditarProtocolo></ModalEditarProtocolo>
                                                        <button className="btn btn-outline-danger ms-2 ho_font_poppins" data-bs-toggle="modal" data-bs-target="#eliminarProtocolo">Eliminar Protocolo</button>
                                                        <ModalEliminarProtocolo></ModalEliminarProtocolo>
                                                    </div>
                                            </div>
                                        </div>
                                        <div className="col-12">
                                            <DragContainer></DragContainer>
                                        </div>
                                    </div>
                                    <ModalEliminarProtocoloItem></ModalEliminarProtocoloItem>
                                    <ModalActualizarProtocoloItem></ModalActualizarProtocoloItem>
                                </div>
                        </ContextoProtocoloItemAActualizar.Provider>
                    </ContextoItemAEliminar.Provider>
                </ContextoItems.Provider>
            </ContextoProtocolo.Provider>
            :
            "Loading ..."
            }
        </div>
    );
}

export default VerProtocolo;

