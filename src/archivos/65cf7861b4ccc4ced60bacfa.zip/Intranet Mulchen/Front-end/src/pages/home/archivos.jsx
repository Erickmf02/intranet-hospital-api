import React from "react";
import Navbar from '../../components/navbar';
import "./archivos.css"



function Archivos() {
    return(
  <div>
    <Navbar/>

    <header className="header_archivos">
    </header>

 </div>

    );

}

export default Archivos;