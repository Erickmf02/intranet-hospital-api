import { createContext, useEffect, useState, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

// Componentes
import Navbar from "../../components/navbar";
import Buscador from "../../components/buscador";
import CartaCarpeta from "./components/cartaCarpeta";
import BotonAddCarpeta from "./components/botonAddCarpeta/botonAddCarpeta";
import RutaCarpeta from "./components/rutaCarpeta";
import ModalEliminarCarpeta from "./components/modalEliminarCarpeta";
import ModalError from "../../components/modalError";
import ModalEditarCarpeta from "./components/modalEditarCarpeta";
import ModalAdministradores from "./components/modalAdministradores";
import BotonCargando from "../../components/botonCargando";

// Constantes y utilidades
import { URL_API } from "../../constantes";
import { obtenerSesion, tienePermisosSobreCarpeta, tieneTokenEnFecha } from "../../utils";
import { mostrarErrorModal } from "../../utils/utilsError";

// Contextos
export const ContextoCarpeta = createContext();
export const ContextoModalEliminarCarpeta = createContext();
export const ContextoModalError = createContext();

function Carpeta() {
  // Params y referencias
  const { id } = useParams();
  const navigate = useNavigate();
  const modalEliminarCarpetaRef = useRef();
  const modalErrorRef = useRef();
  const modalEditarRef = useRef();
  const modalAdministradoresRef = useRef();
  const tokenRef = useRef();

  // Estados
  const [tienePermisos, setTienePermisos] = useState(false);
  const [buscador, setBuscador] = useState("");
  const [cargando, setCargando] = useState(true);
  const [carpeta, setCarpeta] = useState(null);

  //Hooks
  const hookCarpeta = {carpeta, setCarpeta}

  // Efectos
  useEffect(() => {
    if (tieneTokenEnFecha()) {
      const token = obtenerSesion().token;
      tokenRef.current = token;
      obtenerDatos();
    } else {
      navigate("/login");
    }
  }, [id]);

  useEffect(()=>{
    setTienePermisos(tienePermisosSobreCarpeta(carpeta));
  }, [carpeta])
  // Funciones
  async function obtenerDatos() {
    try {
      const response = await axios.get(`${URL_API}/carpeta?id=${id}`, { headers: { Authorization: `Bearer ${tokenRef.current}` } });
      const { data } = response;
      setTienePermisos(tienePermisosSobreCarpeta(data));
      setCarpeta(data);
      setCargando(false);
    } catch (e) {
      console.log(e);
      mostrarErrorModal(modalErrorRef, e, navigate);
    }
  }

  const filtrarCarpetas = (carpetas, filtro) => {
    const filtroSinTildes = quitarTildes(filtro.toLowerCase());
    return carpetas.filter((carpeta) => quitarTildes(carpeta.nombre.toLowerCase()).includes(filtroSinTildes));
  };

  return (
    <div className="d-flex flex-column h-100">
      <ModalError ref={modalErrorRef}></ModalError>
      <ContextoModalError.Provider value={modalErrorRef}>
        <Navbar></Navbar>
        {cargando ? (
          <div>cargando...</div>
        ) : (
          <ContextoCarpeta.Provider value={hookCarpeta}>
            <ContextoModalEliminarCarpeta.Provider value={modalEliminarCarpetaRef}>
              <div className="container-fluid flex-grow-1 d-flex flex-column">
                <div className="flex-grow-1 d-flex flex-column row d-flex" style={{ backgroundColor: "#F0F1F6" }}>
                  <div className="col-12 d-flex flex-column h-100">
                    {carpeta.conPortada && (
                      <div className="row text-center ho_font_poppins py-2 " style={{ gap: "12px" }}>
                        <div className="col-12 d-flex flex-column">
                          <div className="row">
                            <h1 className="m-0 p-0">{carpeta.nombre}</h1>
                          </div>
                          <div className="row">
                            <p className="m-0 p-0">{carpeta.descripcion}</p>
                          </div>
                        </div>
                        <div className="col-12"></div>
                      </div>
                    )}
                    <div className="row flex-grow-1" style={{ backgroundColor: "#DADCE5" }}>
                      <div className="col-12 d-flex flex-column">
                        <RutaCarpeta carpetas={obtenerRutaCompleta(carpeta)}></RutaCarpeta>
                        {tienePermisos && (
                          <div className="row px-3 mb-3">
                            <div className="col-12 p-0 d-flex">
                              <ModalEliminarCarpeta ref={modalEliminarCarpetaRef}></ModalEliminarCarpeta>
                              <ModalEditarCarpeta ref={modalEditarRef}></ModalEditarCarpeta>
                              <ModalAdministradores ref={modalAdministradoresRef} administradores={carpeta.administradores} carpeta={carpeta} setCarpeta={setCarpeta}></ModalAdministradores>
                              <div className="row g-2 w-100">
                                <div className="col-12 col-md-auto d-flex justify-content-center">
                                  <BotonCargando onClick={() => { modalEditarRef.current.abrir() }} text={"Editar carpeta"} estilos={"ho_btn-small"}></BotonCargando>
                                </div>
                                <div className="col-12 col-md-auto d-flex justify-content-center">
                                  <BotonCargando onClick={() => modalEliminarCarpetaRef.current.abrir(carpeta, () => navigate(`/carpeta/${carpeta.padre._id}`))} text={"Eliminar carpeta"} estilos={"ho_btn-red ho_btn-small"}></BotonCargando>
                                </div>
                                <div className="col-12 col-md-auto d-flex justify-content-center">
                                  <BotonCargando onClick={() => modalAdministradoresRef.current.abrir()} text={"Administradores"} estilos={"ho_btn-small"}></BotonCargando>
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                        <div className="row px-3 mb-3">
                          <Buscador value={buscador} setValue={setBuscador}></Buscador>
                        </div>
                        <div className="row flex-grow-1">
                          <div className="col-12">
                            <div className="row mb-3 px-1 g-4 row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 ho_contenedor_cartas_carpetas">
                              {tienePermisosSobreCarpeta(carpeta) && <BotonAddCarpeta carpeta={carpeta} setCarpeta={setCarpeta}></BotonAddCarpeta>}
                              {filtrarCarpetas(carpeta.hijos, buscador).map((carpeta) => (
                                <CartaCarpeta key={carpeta._id} carpeta={carpeta}></CartaCarpeta>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </ContextoModalEliminarCarpeta.Provider>
          </ContextoCarpeta.Provider>
        )}
        <footer>
          <p>&copy; Villagra #455 Hospital Mulchen</p>
        </footer>
      </ContextoModalError.Provider>
    </div>
  );
}

export default Carpeta;

const quitarTildes = (str) => {
  return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
};

function obtenerRutaCompleta(carpeta, ruta = []) {
  if (!carpeta) {
    return ruta;
  }

  const nuevaRuta = [{ nombre: carpeta.nombre, _id: carpeta._id, tipo: carpeta.tipo }, ...ruta];

  if (carpeta.padre) {
    return obtenerRutaCompleta(carpeta.padre, nuevaRuta);
  }
  return nuevaRuta;
}