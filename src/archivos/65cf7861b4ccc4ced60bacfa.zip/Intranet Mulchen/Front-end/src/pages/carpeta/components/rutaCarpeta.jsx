import React from "react";
import { Link } from "react-router-dom";
function RutaCarpeta({ carpetas }) {
  function renderRuta() {
    return carpetas.map((carpeta, index) => (
      <React.Fragment key={carpeta._id}>
        {index === 0 && <span> / </span>}
        {index !== 0 && <span> / </span>}
        <Link to={`/carpeta/${carpeta._id}`} className={`ho_color_white ${index == carpetas.length - 1 ? "fw-semibold" : ""}`}>{carpeta.nombre}</Link>
      </React.Fragment>
    ));
  }

  return (
    <div className="row px-3 mb-3 ho_bg_azul_5 ho_font_poppins ho_color_white ho_fs_16">
      <div className="col-12 p-0">
        {renderRuta()}
      </div>
    </div>
  );
}

export default RutaCarpeta;
