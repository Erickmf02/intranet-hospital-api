import React, { createContext, useEffect, useState, useRef } from "react";
import NavBar from "../../components/navbar.jsx";
import "./panelAdmin.css";
import ModalAgregarProtocolo from "../../components/modalAgregarProtocolo.jsx";
import axios from 'axios';
import "./cartaProtocolo.css"
import { Link } from "react-router-dom";

import { IP, PUERTO_API } from "../../constantes.js";
import { obtenerSesion, tieneTokenEnFecha } from "../../utils.js";
import { useNavigate } from "react-router-dom";

export const ContextoProtocolo = createContext();

function quitarAcentos (cadena) {
  return cadena.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
};

function PanelAdmin() {
  const navigate = useNavigate();
  const [cargando, setCargando] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  const [protocolos, setProtocolos] = useState([]);
  const estadoProtocolos = {
    protocolos,
    setProtocolos,
  }
  

  useEffect(function(){
    async function llamarDatos() {
      try {
        const response = await axios.get(`http://${IP}:${PUERTO_API}/protocolo`);
        setProtocolos(response.data);
        setCargando(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setCargando(false);
      }
    }

    llamarDatos();
  }, [])
  
  const filteredProtocolos = protocolos.filter(
    (protocolo) =>
      quitarAcentos(protocolo.nombre.toLowerCase()).includes(
        quitarAcentos(searchTerm.toLowerCase())
      ) ||
      quitarAcentos(protocolo.abreviacion.toLowerCase()).includes(
        quitarAcentos(searchTerm.toLowerCase())
      )
  );

  function handleSearchChange (event) {
    setSearchTerm(event.target.value);
  };

  const inputRef = useRef(null);

  const handleClick = () => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  useEffect(()=>{
    if(tieneTokenEnFecha()){
      
    }else{
      navigate("/login")
      return;
    }
  },[])

  return (
    <div className="d-flex flex-column h-100">
      <NavBar></NavBar>
      {!cargando ? (
        <ContextoProtocolo.Provider value={estadoProtocolos}>
          <ModalAgregarProtocolo></ModalAgregarProtocolo>
          <div className="container-fluid flex-grow-1 ho_bg_white">
            <div className="row">
              <div className="col-12">
                <div className="row">
                  <div className="col-12">
                    <div className="row ho_font_poppins ho_color_black p-3">
                      <h1 className="col-12 ho_fs_32 fw-bold mb-0 p-0 text-center mb-2">
                        Calidad
                      </h1>
                      <h3 className="col-12 ho_fs_16 mb-0 p-0 text-center mb-2">
                        Busca el protocolo al cual necesitas acceder a su información.
                      </h3>
                        <div className="col-12 d-flex justify-content-center mb-2 m-0">
                          <button className="btn ho_btn_orange" data-bs-toggle="modal" data-bs-target="#modalCrearProtocolo">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="M5.33 3.272a3.5 3.5 0 0 1 4.472 4.473L20.647 18.59l-2.122 2.121L7.68 9.867a3.5 3.5 0 0 1-4.472-4.474L5.444 7.63a1.5 1.5 0 0 0 2.121-2.121zm10.367 1.883l3.182-1.768l1.414 1.415l-1.768 3.181l-1.768.354l-2.12 2.121l-1.415-1.414l2.121-2.121zm-7.071 7.778l2.121 2.122l-4.95 4.95A1.5 1.5 0 0 1 3.58 17.99l.097-.107z"/></svg>
                            Administrar
                            </button>
                        </div>
                    </div>
                  </div>
                  <div className="col-12 ho_bg_white p-3">
                    <div className="row">
                      <div className="col-12 mb-3">
                        <div className="row">
                          <div className="col-12 mb-2">
                            <div className="ho_buscador" onClick={handleClick}>
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" color="#1F7F98"><path fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 10a7 7 0 1 0 14 0a7 7 0 1 0-14 0m18 11l-6-6"/></svg>
                              <input className="ho_color_blue ho_font_poppins ho_fs-16" type="text" placeholder="Buscar..." ref={inputRef} onChange={handleSearchChange}/>
                            </div>
                          </div>
                          <div className="col-12">
                            <button className="btn ho_btn_blue ho_font_poppins">Filtros</button>
                          </div>
                        </div>
                      </div>
                      <div className="col-12">
                        <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 g-3 ho_contenedor_cartas">
                          {filteredProtocolos.map((protocolo)=>(
                            <div className="col" key={protocolo._id}>
                              <Link to={`/protocolo/${protocolo._id}`} style={{textDecoration: "none"}}>
                                <div  className="ho_carta_protocolo" >
                                  <div className="ho_carta_protocolo_cuerpo ho_font_poppins">
                                    <h4 className="mb-0 ho_color_white ho_fs_24 fw-normal"> {protocolo.nombre} </h4>
                                    <h5 className="mb-0 ho_color_orange fw-semibold ho_fs_24"> {protocolo.abreviacion} </h5>
                                  </div>
                                </div>
                              </Link>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </ContextoProtocolo.Provider>
      ) : (
        <div className="container-fluid">cargando...</div>
      )}
      <footer>
        <p>&copy; Villagra #455 Hospital Mulchen</p>
      </footer>
    </div>
  );
}

function obtenerImagen() {
  const arrayDeUrls = [
    "https://img.freepik.com/foto-gratis/fondo-azulejo-mosaico-piscina-textura-fondo-pantalla-banner-telon-fondo_1258-71982.jpg?size=626&ext=jpg&ga=GA1.1.1771150361.1706136469&semt=ais",
    "https://img.freepik.com/foto-gratis/patron-verano-fotos-instantaneas_23-2147809886.jpg?size=626&ext=jpg&ga=GA1.1.1771150361.1706136469&semt=ais",
    "https://img.freepik.com/foto-gratis/edificio-hermoso-negocio-oficina-arquitectura-forma-ventana-cristal_74190-6428.jpg?size=626&ext=jpg&ga=GA1.1.1771150361.1706136469&semt=ais",
    "https://img.freepik.com/foto-gratis/primer-plano-edificios-oficinas-modernos_1359-1050.jpg?size=626&ext=jpg&ga=GA1.1.1771150361.1706136469&semt=ais",
    "https://img.freepik.com/foto-gratis/fondo-geometrico-abstracto-colorido-papel-forma_23-2148058156.jpg?size=626&ext=jpg&ga=GA1.1.1771150361.1706136469&semt=ais",
    "https://img.freepik.com/foto-gratis/fondo-azul-verde-patron-geometrico_1340-24241.jpg?size=626&ext=jpg&ga=GA1.1.1771150361.1706136469&semt=ais",
    "https://img.freepik.com/foto-gratis/fondo-azul_1160-921.jpg?size=626&ext=jpg&ga=GA1.1.1771150361.1706136469&semt=ais",
    "https://img.freepik.com/foto-gratis/cubitos-hielo-azul-fondo-blanco_1340-24229.jpg?size=626&ext=jpg&ga=GA1.1.1771150361.1706136469&semt=ais",
    "https://img.freepik.com/foto-gratis/fondo-baja-poli-estilo-grunge_1048-15850.jpg?size=626&ext=jpg&ga=GA1.1.1771150361.1706136469&semt=ais"

  ]
  if (!Array.isArray(arrayDeUrls) || arrayDeUrls.length === 0) {
    return null; // Manejo de caso vacío o no válido
  }

  const indiceAleatorio = Math.floor(Math.random() * arrayDeUrls.length);
  return arrayDeUrls[indiceAleatorio];
}

export default PanelAdmin;
