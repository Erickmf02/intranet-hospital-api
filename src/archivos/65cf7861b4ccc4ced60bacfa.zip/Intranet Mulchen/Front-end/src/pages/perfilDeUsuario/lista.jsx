import React, { useEffect, useRef, useState } from "react";
import Navbar from "../../components/navbar";
import backgroundjpg from "./../home/img/background.jpg";
import './lista.css';
import axios from "axios";
import { URL_API } from "../../constantes";
import ListaItem from "./components/listaItem";
import ModalEliminarUsuario from "./components/modalEliminarUsuario";
import Buscador from "../../components/buscador";
import { tienePermisosDeAdministrador, tieneToken, obtenerSesion} from "../../utils";
import { useNavigate } from "react-router-dom";

function Lista() {
    const navigate = useNavigate();
    const [token, setToken] = useState(null);


    const [loading, setLoading] = useState(true);
    const [usuarios, setUsuarios] = useState([]);
    const [buscador, setBuscador] = useState("");
    
    const modalEliminarUsuarioRef = useRef();
    useEffect(()=>{
        if(token){
            if(!tienePermisosDeAdministrador()){
                navigate("/")
            }else{
                getData();
            }
        }
    }, [token])

    useEffect(() => {
        if(tieneToken()){
            const sessionData = obtenerSesion();
            const { token } = sessionData;
            setToken(token);
        }else{
            navigate("/login")
        }
    }, []);

    async function getData(){
        try {
            const response = await axios.get(`${URL_API}/usuario`,{
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            const { data } = response;
            setUsuarios(data);
            setLoading(false);
        } catch (e) {
            console.log(e)
        }
    }

    const filtrarUsuarios = (usuarios, filtro) => {
        const filtroSinTildes = quitarTildes(filtro.toLowerCase());
        return usuarios.filter((usuario) => quitarTildes(usuario.nombre.toLowerCase()).includes(filtroSinTildes));
    };

    return (
        <div>
            <Navbar />
            {!loading
            ?<div className="body">
                <ModalEliminarUsuario ref={modalEliminarUsuarioRef} usuarios={usuarios} setUsuarios={setUsuarios}></ModalEliminarUsuario>
                <div>
                    <img className="mi_imagen_fondo" src={backgroundjpg} alt="background img" />
                    <div className="mi_tarjeta_lista">
                        <h2>Listado de funcionarios</h2>
                        <div className="mi_search_container">
                            <div className="mb-4 px-4">
                                <Buscador value={buscador} setValue={setBuscador}></Buscador>
                            </div>
                        </div>
                        <ul className="lista_personas list-group" >
                            {filtrarUsuarios(usuarios, buscador).map(usuario => (
                                <ListaItem key={usuario._id} usuario={usuario} setUsuarios={setUsuarios} usuarios={usuarios} modalEliminar={modalEliminarUsuarioRef}></ListaItem>
                            ))}
                        </ul>
                    </div>
                </div>
            </div>
            :<>Cargando...</>
            }
            <footer>
                <p>&copy; Villagra #455 Hospital Mulchen</p>
            </footer>
        </div>
    );
}

const quitarTildes = (str) => {
    return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  };

export default Lista;
