import { useContext } from "react";
import { ContextoDrag, ContextoEstadoBotonesDrag } from "./dragContainer"
import { ContextoItems } from "../../pages/verProtocolo/verProtocolo";
import axios from "axios";
import { IP, PUERTO_API } from "../../constantes";

function ProtocoloItemDragButtons({listeners}){
    const { estadoBotonesDrag, setEstadoBotonesDrag } = useContext(ContextoEstadoBotonesDrag);
    const { items, setItems } = useContext(ContextoItems);
    const { isDraggingActive , setIsDraggingActive} = useContext(ContextoDrag);
    
    async function detenerDragging(){
        try{
            setEstadoBotonesDrag("cargando");
            const updatedItems = items.map((item, index) => ({
                _id: item._id,
                posicion: index + 1,
            }));

            //eliminar despues
            await new Promise(resolve => setTimeout(resolve, 2000));

            const response = await axios.put(`http://${IP}:${PUERTO_API}/protocolo_item/actualizar_posiciones`,{
                posiciones: updatedItems,
            })
            
            if( response.status >= 200 && response.status < 300 ){
                console.log("actualizado")
            }else{
                console.log("no actualizado")
            }
            setIsDraggingActive(false);
            setEstadoBotonesDrag("habilitado");
        }catch(error){
            console.log(error);
        }
    }

    return (
        <div className="ho_card_protocol_item_drag_buttons">
            <button className="btn btn-outline-primary" onClick={detenerDragging} disabled={estadoBotonesDrag !== "habilitado"}>
            {
                estadoBotonesDrag === "cargando"
                ?
                <>
                    <span className="spinner-border spinner-border-sm me-2" aria-hidden="true"></span>
                    <span role="status">Cargando...</span>
                </>
                :
                <>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M6.758 17.243L12.001 12m5.243-5.243L12 12m0 0L6.758 6.757M12.001 12l5.243 5.243"/></svg>
                </>
            }
            </button>
            <button className="btn btn-outline-primary" {...listeners}>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 1024 1024"><path fill="currentColor" d="M909.3 506.3L781.7 405.6a7.23 7.23 0 0 0-11.7 5.7V476H548V254h64.8c6 0 9.4-7 5.7-11.7L517.7 114.7a7.14 7.14 0 0 0-11.3 0L405.6 242.3a7.23 7.23 0 0 0 5.7 11.7H476v222H254v-64.8c0-6-7-9.4-11.7-5.7L114.7 506.3a7.14 7.14 0 0 0 0 11.3l127.5 100.8c4.7 3.7 11.7.4 11.7-5.7V548h222v222h-64.8c-6 0-9.4 7-5.7 11.7l100.8 127.5c2.9 3.7 8.5 3.7 11.3 0l100.8-127.5c3.7-4.7.4-11.7-5.7-11.7H548V548h222v64.8c0 6 7 9.4 11.7 5.7l127.5-100.8a7.3 7.3 0 0 0 .1-11.4"/></svg>
            </button>
        </div>
    );
}

export default ProtocoloItemDragButtons;