import { useContext, useState } from "react";
import { ContextoItemAEliminar, ContextoProtocoloItemAActualizar, ContextoItems} from "../../pages/verProtocolo/verProtocolo.jsx";
import { ContextoDrag } from "./dragContainer.jsx";
import { useSortable } from "@dnd-kit/sortable"
import { CSS } from "@dnd-kit/utilities";
import ProtocoloItemDragButtons from "./protocoloItemDragButtons.jsx";
import {IP, PUERTO_API} from "../../constantes.js";


import "./protocoloItem.css"

function ProtocoloItem ({item, opacar}){

    //eliminar item
    const {itemAEliminar, setItemAEliminar} = useContext(ContextoItemAEliminar);
    function handleEliminarItemClick(){
        setItemAEliminar(item);
    }
    //actualizar item
    const {protocoloItemAActualizar, setProtocoloItemAActualizar} = useContext(ContextoProtocoloItemAActualizar);
    function cambiarProtocoloItemAActualizar(){
        setProtocoloItemAActualizar(item);
    }

    //drag and drop
    const {isDraggingActive, setIsDraggingActive} = useContext(ContextoDrag);

    function activarDragging() {
        setIsDraggingActive(true);
    }

    const {attributes, listeners, setNodeRef, transform, transition} = useSortable({
        id: item._id.toString(),
        disabled: !isDraggingActive ? true : false
    });
    const style = {
        transform: CSS.Translate.toString(transform),
        transition,
        opacity: opacar? 0.4 : 1,
    };
    return (
        <div ref={setNodeRef} style={style} {...attributes} className={`ho_card_protocol_item_container mb-3 mb-md-4 col-12 p-0`} >
            <div className={`ho_card_protocolo_item ${isDraggingActive && "ho_no_select"}`}>
                <div className="ho_card_protocol_item_first">
                    <div className="ho_fs_24 fw-medium ho_font_poppins">
                        {item.titulo}  
                    </div>
                    <div className="ho_font_poppins ho_fs_20 d-flex justify-content-center justify-content-md-start ho_color_blue">
                        {selectIcon(item) != null
                        &&
                        <span className="me-2 d-flex align-items-center justify-content-center">
                            {selectIcon(item)}
                        </span>
                        }
                        <span>
                            Archivo&nbsp;
                            <span className="fw-semibold">{item.extension.toUpperCase()}</span>
                        </span>
                    </div>
                </div>
                {
                !isDraggingActive
                ?
                <div className="ho_card_protocol_item_second">
                    <div className="ho_card_protocol_item_buttons_container">
                        <a className="btn btn-primary ho_font_poppins ho_bg_blue" target="_blank" href={`http://${IP}:${PUERTO_API}/protocolo_item/${item._id}/archivo`} >
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><g stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"><path fill="none" strokeDasharray="14" strokeDashoffset="14" d="M6 19h12"><animate fill="freeze" attributeName="stroke-dashoffset" dur="0.4s" values="14;0"/></path><path fill="currentColor" d="M12 4 h2 v6 h2.5 L12 14.5M12 4 h-2 v6 h-2.5 L12 14.5"><animate attributeName="d" calcMode="linear" dur="1.5s" keyTimes="0;0.7;1" repeatCount="indefinite" values="M12 4 h2 v6 h2.5 L12 14.5M12 4 h-2 v6 h-2.5 L12 14.5;M12 4 h2 v3 h2.5 L12 11.5M12 4 h-2 v3 h-2.5 L12 11.5;M12 4 h2 v6 h2.5 L12 14.5M12 4 h-2 v6 h-2.5 L12 14.5"/></path></g></svg>
                            Descargar archivo
                        </a>
                            <div className="dropup">
                                <button className="btn btn-outline-primary" data-bs-toggle="dropdown" aria-expanded="false">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="M5 10c-1.1 0-2 .9-2 2s.9 2 2 2s2-.9 2-2s-.9-2-2-2m14 0c-1.1 0-2 .9-2 2s.9 2 2 2s2-.9 2-2s-.9-2-2-2m-7 0c-1.1 0-2 .9-2 2s.9 2 2 2s2-.9 2-2s-.9-2-2-2"/></svg>
                                </button>
                                <ul className="dropdown-menu">
                                    <li><h6 className="dropdown-header">Opciones</h6></li>
                                    <li><a className="dropdown-item fw-semibold" onClick={activarDragging} >{isDraggingActive?"detener": "Mover archivos"}</a></li>
                                    <li><a className="dropdown-item fw-semibold" data-bs-toggle="modal" data-bs-target="#actualizarProtocoloItemModal" onClick={cambiarProtocoloItemAActualizar}>Editar</a></li>
                                    <li><a className="dropdown-item text-danger fw-semibold" data-bs-toggle="modal" data-bs-target="#eliminarItem" onClick={handleEliminarItemClick}>Eliminar</a></li>
                                </ul>
                            </div>
                    </div>
                    <div className="">
                        <div className="col-auto ho_font_poppins ho_fs_14 ho_color_soft_black mt-2 mt-sm-0 p-0">Ultima actualizacion: {item.ultimaActualizacion} </div>
                    </div>
                </div>
                :
                <ProtocoloItemDragButtons listeners={listeners}></ProtocoloItemDragButtons>
                }
            </div>
        </div>
    );
}
export function selectIcon(item){
    switch (item.extension) {
        case "pdf":
            return (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 512 512"><path fill="currentColor" d="M64 464h48v48H64c-35.3 0-64-28.7-64-64V64C0 28.7 28.7 0 64 0h165.5c17 0 33.3 6.7 45.3 18.7l90.5 90.5c12 12 18.7 28.3 18.7 45.3V304h-48V160h-80c-17.7 0-32-14.3-32-32V48H64c-8.8 0-16 7.2-16 16v384c0 8.8 7.2 16 16 16m112-112h32c30.9 0 56 25.1 56 56s-25.1 56-56 56h-16v32c0 8.8-7.2 16-16 16s-16-7.2-16-16V368c0-8.8 7.2-16 16-16m32 80c13.3 0 24-10.7 24-24s-10.7-24-24-24h-16v48zm96-80h32c26.5 0 48 21.5 48 48v64c0 26.5-21.5 48-48 48h-32c-8.8 0-16-7.2-16-16V368c0-8.8 7.2-16 16-16m32 128c8.8 0 16-7.2 16-16v-64c0-8.8-7.2-16-16-16h-16v96zm80-112c0-8.8 7.2-16 16-16h48c8.8 0 16 7.2 16 16s-7.2 16-16 16h-32v32h32c8.8 0 16 7.2 16 16s-7.2 16-16 16h-32v48c0 8.8-7.2 16-16 16s-16-7.2-16-16v-64z"/></svg>);
        case "word": 
            return (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 512 512"><path fill="currentColor" d="M488.877 52.447H302.306V5.92h-34.779L0 52.563v406.99l265.957 46.527h36.349v-46.353h174.59c9.887-.465 20.879.291 29.37-5.757c6.804-10.41 5.06-23.438 5.641-35.186V75.012c1.221-13.26-9.77-23.903-23.03-22.565m-294.862 282.59c-9.712 5.06-24.252-.233-35.767.581c-7.735-38.5-16.75-76.768-23.67-115.443c-6.805 37.57-15.645 74.79-23.438 112.128c-11.166-.581-22.39-1.28-33.615-2.035c-9.655-51.18-20.995-102.01-30.01-153.305c9.945-.465 19.948-.872 29.893-1.221c5.99 37.047 12.795 73.919 18.03 111.024c8.2-38.036 16.574-76.071 24.717-114.106c11.05-.64 22.1-1.105 33.15-1.687c7.735 39.257 15.644 78.455 24.019 117.537c6.572-40.361 13.841-80.607 20.879-120.91c11.631-.407 23.263-1.047 34.836-1.745c-13.143 56.355-24.659 113.176-39.024 169.182m290.212 97.069H302.306v-36.527h151.21v-23.263h-151.21v-29.079h151.21v-23.263h-151.21v-29.08h151.21v-23.262h-151.21v-29.08h151.21V215.29h-151.21v-29.08h151.21v-23.263h-151.21v-29.079h151.21v-23.263h-151.21v-30.71h181.921z"/></svg>);
        case "excel":
            return (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 512 512"><path fill="currentColor" d="M453.547 273.449H372.12v-40.714h81.427zm0 23.264H372.12v40.714h81.427zm0-191.934H372.12v40.713h81.427zm0 63.978H372.12v40.713h81.427zm0 191.934H372.12v40.714h81.427zm56.242 80.264c-2.326 12.098-16.867 12.388-26.58 12.796H302.326v52.345h-36.119L0 459.566V52.492L267.778 5.904h34.548v46.355h174.66c9.83.407 20.648-.291 29.197 5.583c5.991 8.608 5.41 19.543 5.817 29.43l-.233 302.791c-.29 16.925 1.57 34.2-1.978 50.892m-296.51-91.256c-16.052-32.57-32.395-64.909-48.39-97.48c15.82-31.698 31.408-63.512 46.937-95.327c-13.203.64-26.406 1.454-39.55 2.385c-9.83 23.904-21.288 47.169-28.965 71.888c-7.154-23.323-16.634-45.774-25.3-68.515c-12.796.698-25.592 1.454-38.387 2.21c13.493 29.78 27.86 59.15 40.946 89.104c-15.413 29.081-29.837 58.57-44.785 87.825c12.737.523 25.475 1.047 38.212 1.221c9.074-23.148 20.357-45.424 28.267-69.038c7.096 25.359 19.135 48.798 29.023 73.051c14.017.99 27.976 1.862 41.993 2.676M484.26 79.882H302.326v24.897h46.53v40.713h-46.53v23.265h46.53v40.713h-46.53v23.265h46.53v40.714h-46.53v23.264h46.53v40.714h-46.53v23.264h46.53v40.714h-46.53v26.897H484.26z"/></svg>);
        case "powerpoint":
            return (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 512 512"><path fill="currentColor" d="M488.698 58.311H302.231V5.981h-32.968L0 52.614v406.89l266.066 46.515h36.165v-58.144h174.49c9.942-.465 20.99.524 29.478-5.64c6.745-10.407 5.11-23.432 5.692-35.177V81.104c1.337-13.373-9.82-24.072-23.193-22.793M170.535 275.304c-13.198 6.744-28.316 5.814-42.677 5.349l-.058 68.202l-34.596-2.907l.058-186.35c31.573 1.511 69.831-12.501 95.996 11.163c25.06 30.41 18.431 86.344-18.723 104.543m313.572 145.13H302.231v-36.518h139.545V360.66H302.231v-29.072h139.545V308.33H302.289s-.058-22.792-.116-34.188c23.025 7.151 49.248 6.977 69.83-6.861c22.27-13.199 33.898-38.375 35.817-63.493h-76.517v-75.936l-29.072 5.873V85.752h181.876zm-141.18-304.735c40.41 1.86 74.429 36.021 76.58 76.315h-76.58zM127.8 191.053c11.454-.523 25.641-2.616 33.374 8.14c6.629 11.397 6.28 26.398.756 38.143c-6.628 11.977-21.63 10.815-33.2 12.21c-1.22-19.478-1.105-38.956-.93-58.493"/></svg>);
        default:
            return null;
    }
}

export default ProtocoloItem;

