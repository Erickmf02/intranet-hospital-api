import { useContext, useEffect, useState } from "react";
import { ContextoItems, ContextoProtocolo} from "../../pages/verProtocolo/verProtocolo.jsx";
import axios from "axios";
import {IP, PUERTO_API} from "../../constantes.js";
function ProtocoloItemCrear(){
    const {protocolo, setProtocolo} = useContext(ContextoProtocolo);
    const {items, setItems} = useContext(ContextoItems);
    const [estado, setEstado] = useState("habilitado");

    const [nuevoItem, setNuevoItem] = useState({
        nombre: "",
        archivo: null,
        extensionArchivo: ""
    });

    const handleNombreChange = (event) => {
        setNuevoItem({
            ...nuevoItem,
            nombre: event.target.value
        });
    };

    const handleFileChange = (event) => {
        const file = event.target.files[0]
        if(file){
            setNuevoItem({
                ...nuevoItem,
                archivo: file,
                extensionArchivo: obtenerExtensionArchivo(file.name)
            });
        }else{
            setNuevoItem({
                ...nuevoItem,
                archivo: null,
                extensionArchivo: null
            });
        }
        
    };

    const obtenerExtensionArchivo = (fileName) => {
        return fileName.slice((fileName.lastIndexOf(".") - 1 >>> 0) + 2);
    };

    async function handleGuardar(){
        if(estado === "habilitado"){
            try {
                setEstado("cargando")
                //eliminar despues
                await new Promise(resolve => setTimeout(resolve, 2000));
    
                const formData = new FormData();
                formData.append('id', protocolo._id);
                formData.append('archivo', nuevoItem.archivo);
                formData.append('titulo', nuevoItem.nombre);
    
                const response = await axios.post(`http://${IP}:${PUERTO_API}/protocolo_item`, formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data',
                    },
                });
                const item = response.data;
                const nuevosItems = [item, ...items];
                setItems(nuevosItems);
                setNuevoItem({
                    nombre: "",
                    archivo: null,
                    extensionArchivo: ""
                })
                setEstado("deshabilitado");
            } catch (error) {
                console.log(error);
            }
        }
    }
    useEffect(()=>{
        if(estado !== "cargando"){
            if(nuevoItem.archivo && nuevoItem.nombre && nuevoItem.extensionArchivo){
                setEstado("habilitado");
            }else{
                setEstado("deshabilitado");
            }
        }
    },[nuevoItem])

    return (
        <div className="ho_card_protocol_item_container mb-3 mb-md-4 col-12 p-0">
            <div className="ho_card_protocolo_item">
                <div className="ho_card_protocol_item_first">
                    <div className="ho_font_poppins" style={{width: "100%"}}>
                        <label htmlFor="nombreArchivo" className="form-label m-0">Nombre del archivo</label>
                        <textarea type="text" className="form-control" id="nombreArchivo" aria-describedby="nombreArchivo" rows={1} value={nuevoItem.nombre} onChange={handleNombreChange} />
                    </div>
                    <div className="ho_font_poppins ho_fs_20 d-flex justify-content-center justify-content-md-start ho_color_blue">
                        Ingresar nuevo archivo&nbsp;{ nuevoItem.extensionArchivo && <span className="fw-semibold">{` ${nuevoItem.extensionArchivo.toUpperCase()}`}</span> }
                    </div>
                </div>
                <div className="ho_card_protocol_item_second ho_card_protocol_item_second-one_item">
                
                    <div className="ho_card_protocol_item_buttons_container">
                        <label htmlFor="fileInput" role="button" className="btn btn-outline-primary ho_font_poppins">
                            
                            {
                                nuevoItem.archivo
                                ?
                                <>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1zm12 12a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1zm6-5V8a2 2 0 0 0-2-2h-6l3 3m0-6l-3 3M3 13v3a2 2 0 0 0 2 2h6l-3-3m0 6l3-3"/></svg>
                                    Cambiar archivo
                                </>
                                :
                                <>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                        <g stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2">
                                            <path fill="none" strokeDasharray="14" strokeDashoffset="14" d="M6 19h12">
                                                <animate fill="freeze" attributeName="stroke-dashoffset" dur="0.4s" values="14;0"/>
                                            </path>
                                            <path fill="currentColor" d="M12 15 h2 v-6 h2.5 L12 4.5M12 15 h-2 v-6 h-2.5 L12 4.5">
                                                <animate attributeName="d" calcMode="linear" dur="1.5s" keyTimes="0;0.7;1" repeatCount="indefinite" values="M12 15 h2 v-6 h2.5 L12 4.5M12 15 h-2 v-6 h-2.5 L12 4.5;M12 15 h2 v-3 h2.5 L12 7.5M12 15 h-2 v-3 h-2.5 L12 7.5;M12 15 h2 v-6 h2.5 L12 4.5M12 15 h-2 v-6 h-2.5 L12 4.5"/>
                                            </path>
                                        </g>
                                    </svg>
                                    Subir archivo
                                </>
                            }
                        </label>
                        <button className="btn btn-primary ho_font_poppins ho_bg_blue" disabled={estado !== "habilitado"} onClick={handleGuardar}>
                        {
                            estado === "cargando"
                            ?
                            <>
                                <span className="spinner-border spinner-border-sm me-2" aria-hidden="true"></span>
                                <span role="status">Cargando...</span>
                            </>
                            :
                            <>
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="M17.59 3.59c-.38-.38-.89-.59-1.42-.59H5a2 2 0 0 0-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V7.83c0-.53-.21-1.04-.59-1.41zM12 19c-1.66 0-3-1.34-3-3s1.34-3 3-3s3 1.34 3 3s-1.34 3-3 3m1-10H7c-1.1 0-2-.9-2-2s.9-2 2-2h6c1.1 0 2 .9 2 2s-.9 2-2 2"/></svg>
                                Guardar
                            </>
                        }
                        </button>
                        <input type="file" id="fileInput" style={{ display: 'none' }} onChange={handleFileChange} />
                    </div>
                </div>
            </div>
        </div>
    );
}

export default ProtocoloItemCrear;

