import { useContext, useRef, useEffect, useState } from "react";
import { ContextoItemAEliminar, ContextoItems } from "../../pages/verProtocolo/verProtocolo.jsx";
import bootstrap from "bootstrap/dist/js/bootstrap.js";
import axios from "axios";
import {IP, PUERTO_API} from "../../constantes.js";
function ModalEliminarProtocoloItem(){

    const referenciaModal = useRef(null);
    const modalBootstrap = useRef(null);

    const {itemAEliminar, setItemAEliminar} = useContext(ContextoItemAEliminar);
    const {items, setItems} = useContext(ContextoItems);

    const [estado, setEstado] = useState("habilitado")

    async function eliminarItem() {
        if(estado === "habilitado"){
            try {
                setEstado("cargando");
                //eliminar despues
                await new Promise(resolve => setTimeout(resolve, 2000));
                await axios.delete(`http://${IP}:${PUERTO_API}/protocolo_item/${itemAEliminar._id}`);
    
                const nuevosItems = items.filter((item) => item._id != itemAEliminar._id).map((item, index) => {
                    return {
                        ...item,
                        posicion: index + 1,
                    };
                });
                setItems(nuevosItems);
                await modalBootstrap.current.hide()
                //setEstado("habilitado");
            } catch (error) {
                console.log(error)
            }
        }
    };

    useEffect(()=>{
        if(referenciaModal){
            modalBootstrap.current = new bootstrap.Modal(referenciaModal.current);
            //testing
            referenciaModal.current.addEventListener("hidden.bs.modal", event=>{
                setEstado("habilitado");
            })
        }
    }, [referenciaModal])

    return(
        <div className="modal fade" id="eliminarItem" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" ref={referenciaModal}>
            <div className="modal-dialog">
                <div className="modal-content">
                <div className="modal-header">
                    <h1 className="modal-title fs-5" id="exampleModalLabel">Eliminar archivo.</h1>
                    <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div className="modal-body">
                    {itemAEliminar==null
                    ?
                    "esperando"
                    :
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-12">
                                {`¿Estás seguro de que deseas eliminar el archivo `}
                                <span className="text-danger fw-semibold text-decoration-underline">
                                    {` ${itemAEliminar.titulo}?`}
                                </span>
                            </div>
                        </div>
                    </div>
                }
                </div>
                {itemAEliminar == null
                ?
                "esperando"
                :
                <div className="modal-footer">
                    <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">cancelar</button>
                    <button type="button" className="btn btn-danger" onClick={eliminarItem} disabled={ estado !== "habilitado"}>
                    {
                        estado === "cargando"
                        ?
                        <>
                            <span className="spinner-border spinner-border-sm me-2" aria-hidden="true"></span>
                            <span role="status">Cargando...</span>
                        </>
                        :
                        "Eliminar"
                    }
                    </button>
                </div>
                }
                </div>
            </div>
        </div>
    );
}

export default ModalEliminarProtocoloItem;