import { useContext, useRef, useEffect, useState } from "react";
import { ContextoProtocoloItemAActualizar, ContextoItems } from "../../pages/verProtocolo/verProtocolo";
import { Modal } from "bootstrap/dist/js/bootstrap.js";
import axios from "axios";
import { IP, PUERTO_API } from "../../constantes";

function ModalActualizarProtocoloItem(){
    const {protocoloItemAActualizar, setProtocoloItemAActualizar} = useContext(ContextoProtocoloItemAActualizar);
    const {items, setItems} = useContext(ContextoItems);
    const [estado, setEstado] = useState("deshabilitado");

    const [nuevoItemActualizado, setNuevoItemActualizado] = useState({
        nombre: "",
        archivo: null,
        extensionArchivo: ""
    });

    const handleNombreChange = (event) => {
        setNuevoItemActualizado({
            ...nuevoItemActualizado,
            nombre: event.target.value
        });
    };

    const handleFileChange = (event) => {
        const file = event.target.files[0]
        if(file){
            setNuevoItemActualizado({
                ...nuevoItemActualizado,
                archivo: file,
                extensionArchivo: obtenerExtensionArchivo(file.name)
            });
        }else{
            setNuevoItemActualizado({
                ...nuevoItemActualizado,
                archivo: null,
                extensionArchivo: null
            });
        }
        
    };

    const obtenerExtensionArchivo = (fileName) => {
        return fileName.slice((fileName.lastIndexOf(".") - 1 >>> 0) + 2);
    };

    async function handleGuardar(){
        if(estado === "habilitado"){
            try {
                setEstado("cargando")
                //eliminar despues
                await new Promise(resolve => setTimeout(resolve, 2000));
    
                const formData = new FormData();
                formData.append('archivo', nuevoItemActualizado.archivo);
                formData.append('titulo', nuevoItemActualizado.nombre);

                const response = await axios.put(`http://${IP}:${PUERTO_API}/protocolo_item/${protocoloItemAActualizar._id}`, formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data',
                    },
                });
                const updatedItem = response.data;
                // Encontrar el índice del item a actualizar en el array items
                const indexToUpdate = items.findIndex(
                    (item) => item._id === updatedItem._id
                );

                if (indexToUpdate !== -1) {
                    // Crear una copia del array items
                    const updatedItems = [...items];
                    // Reemplazar el item en el índice correspondiente
                    updatedItems[indexToUpdate] = updatedItem;
                    // Actualizar el estado con la nueva lista de items
                    setItems(updatedItems);
                }
                setNuevoItemActualizado({
                    nombre: "",
                    archivo: null,
                    extensionArchivo: ""
                })
                setEstado("deshabilitado");
                modalBootstrap.current.hide();
            } catch (error) {
                console.log(error);
            }
        }
    }
    useEffect(()=>{
        if(estado !== "cargando"){
            if(nuevoItemActualizado.archivo || nuevoItemActualizado.nombre){
                setEstado("habilitado");
            }else{
                setEstado("deshabilitado");
            }
        }
    },[nuevoItemActualizado])

    const referenciaModal = useRef(null);
    const modalBootstrap = useRef(null);

    useEffect(()=>{
        if(referenciaModal){
            modalBootstrap.current = new Modal(referenciaModal.current);
        }
    }, [referenciaModal])

    return (
        <div className="modal fade" id="actualizarProtocoloItemModal" tabIndex="-1" aria-labelledby="actualizarProtocoloItemLabel" aria-hidden="true" ref={referenciaModal}>
            <div className="modal-dialog">
                {
                protocoloItemAActualizar == null
                ?
                "cargando..."
                :
                <div className="modal-content">
                    <div className="modal-header">
                        <h1 className="modal-title fs-5" id="exampleModalLabel">Editar archivo</h1>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div className="modal-body">
                        <div className="container-fluid">
                            <div className="row">
                                <div className="col-12 mb-2">
                                    <label htmlFor="nuevoNombreArchivoModal" className="form-label">Nuevo nombre del archivo</label>
                                    <input type="text" className="form-control" id="nuevoNombreArchivoModal" placeholder="Ingresar nuevo nombre del archivo" onChange={handleNombreChange} value={nuevoItemActualizado.nombre}/>
                                </div>
                                <div className="col-12">
                                    <label htmlFor="ActualizarProtocoloItemInputFile" role="button" className="btn btn-outline-primary ho_font_poppins">
                                        {
                                            nuevoItemActualizado.archivo
                                            ?
                                            <>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1zm12 12a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1zm6-5V8a2 2 0 0 0-2-2h-6l3 3m0-6l-3 3M3 13v3a2 2 0 0 0 2 2h6l-3-3m0 6l3-3"/></svg>
                                                Cambiar archivo
                                            </>
                                            :
                                            <>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                                    <g stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2">
                                                        <path fill="none" strokeDasharray="14" strokeDashoffset="14" d="M6 19h12">
                                                            <animate fill="freeze" attributeName="stroke-dashoffset" dur="0.4s" values="14;0"/>
                                                        </path>
                                                        <path fill="currentColor" d="M12 15 h2 v-6 h2.5 L12 4.5M12 15 h-2 v-6 h-2.5 L12 4.5">
                                                            <animate attributeName="d" calcMode="linear" dur="1.5s" keyTimes="0;0.7;1" repeatCount="indefinite" values="M12 15 h2 v-6 h2.5 L12 4.5M12 15 h-2 v-6 h-2.5 L12 4.5;M12 15 h2 v-3 h2.5 L12 7.5M12 15 h-2 v-3 h-2.5 L12 7.5;M12 15 h2 v-6 h2.5 L12 4.5M12 15 h-2 v-6 h-2.5 L12 4.5"/>
                                                        </path>
                                                    </g>
                                                </svg>
                                                Subir archivo
                                            </>
                                        }
                                    </label>
                                    <input type="file" id="ActualizarProtocoloItemInputFile" style={{ display: 'none' }} onChange={handleFileChange}/>
                                </div>
                                <div className="col-12">
                                    <div className="ho_font_poppins ho_fs_20 d-flex justify-content-center justify-content-md-start ho_color_blue">
                                        Ingresar nuevo archivo&nbsp;{ nuevoItemActualizado.extensionArchivo && <span className="fw-semibold">{` ${nuevoItemActualizado.extensionArchivo.toUpperCase()}`}</span> }
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button className="btn btn-primary ho_font_poppins ho_bg_blue" disabled={estado !== "habilitado"} onClick={handleGuardar}>
                        {
                            estado === "cargando"
                            ?
                            <>
                                <span className="spinner-border spinner-border-sm me-2" aria-hidden="true"></span>
                                <span role="status">Cargando...</span>
                            </>
                            :
                            <>
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="M17.59 3.59c-.38-.38-.89-.59-1.42-.59H5a2 2 0 0 0-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V7.83c0-.53-.21-1.04-.59-1.41zM12 19c-1.66 0-3-1.34-3-3s1.34-3 3-3s3 1.34 3 3s-1.34 3-3 3m1-10H7c-1.1 0-2-.9-2-2s.9-2 2-2h6c1.1 0 2 .9 2 2s-.9 2-2 2"/></svg>
                                Actualizar
                            </>
                        }
                        </button>
                    </div>
                </div>
                }
            </div>
        </div>
    );
}

export default ModalActualizarProtocoloItem;