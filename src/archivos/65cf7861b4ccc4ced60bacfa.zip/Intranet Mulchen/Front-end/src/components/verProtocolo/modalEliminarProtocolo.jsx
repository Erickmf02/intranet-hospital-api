import { useEffect, useRef, useState, useContext } from "react";
import { ContextoProtocolo } from "../../pages/verProtocolo/verProtocolo.jsx";
import { Modal } from "bootstrap/dist/js/bootstrap.js";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import {IP, PUERTO_API} from "../../constantes.js";

function ModalEliminarProtocolo(){
    const [textoEliminar, setTextoEliminar] = useState('');
    const [estado, setEstado] = useState("deshabilitado");

    const {protocolo, setProtocolo} = useContext(ContextoProtocolo);

    const referenciaModal = useRef(null);
    const modalBootstrap = useRef(null);

    const navigate = useNavigate();

    const handleInputChange = (event) => {
        const textoInput = event.target.value;
        setTextoEliminar(textoInput);
        if(textoInput.toLowerCase() === protocolo.abreviacion.toLowerCase()){
            setEstado("habilitado");
        }else{
            setEstado("deshabilitado");
        }
    };
    function limpiarEliminar(){
        setTextoEliminar("");
        setEstado("deshabilitado");
    }

    async function handleEliminarClick(){
        if(estado === "habilitado"){
            
            setEstado("cargando");
            //eliminar despues
            await new Promise(resolve => setTimeout(resolve, 2000));
            const response = await axios.delete(`http://${IP}:${PUERTO_API}/protocolo/${protocolo._id}`)
            await modalBootstrap.current.hide();
            limpiarEliminar();
            navigate("/administracion");
        }
    };

    useEffect(()=>{
        if(referenciaModal){
            modalBootstrap.current = new Modal(referenciaModal.current);
        }
    }, [referenciaModal])
    
    return (
        <div className="modal fade" id="eliminarProtocolo" data-bs-backdrop="static" tabIndex="-1" aria-labelledby="eliminarProtocoloLabel" aria-hidden="true" ref={referenciaModal}>
            <div className="modal-dialog">
                <div className="modal-content">
                <div className="modal-header">
                    <h1 className="modal-title fs-5" id="exampleModalLabel">Eliminar protocolo</h1>
                    <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={limpiarEliminar}></button>
                </div>
                <div className="modal-body">
                    <div className="mb-3">
                        {`¿Estas seguro de que deseas eliminar el protocolo de ${protocolo.nombre}`}
                    </div>
                    <div className="mb-3">
                        <label htmlFor="formEliminar" className="form-label">Escribe <span className="text-danger fw-bold text-decoration-underline">{protocolo.abreviacion}</span> para poder eliminar el protocolo</label>
                        <input type="text" className="form-control" id="formEliminar" placeholder="Escribe aquí" value={textoEliminar} onChange={handleInputChange} />
                    </div>
                </div>
                <div className="modal-footer">
                    <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={limpiarEliminar}>Cancelar</button>
                    <button type="button" className="btn btn-danger" disabled={ estado !== "habilitado" } onClick={handleEliminarClick}>
                    {
                        estado === "cargando"
                        ?
                        <>
                            <span className="spinner-border spinner-border-sm me-2" aria-hidden="true"></span>
                            <span role="status">Cargando...</span>
                        </>
                        :
                        "Eliminar definitivamente"
                    }
                    </button>
                </div>
                </div>
            </div>
        </div>
    );
}

export default ModalEliminarProtocolo;