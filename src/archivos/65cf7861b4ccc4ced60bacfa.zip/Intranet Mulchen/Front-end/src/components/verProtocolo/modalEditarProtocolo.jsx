import { useContext, useRef, useEffect, useState } from "react";
import { ContextoProtocolo } from "../../pages/verProtocolo/verProtocolo.jsx";
import { Modal } from "bootstrap/dist/js/bootstrap.js";
import {IP, PUERTO_API} from "../../constantes.js";
import axios from "axios";
function ModalEditarProtocolo(){
    const {protocolo, setProtocolo} = useContext(ContextoProtocolo);

    const [protocoloActualizado, setProtocoloActualizado] = useState({
        nombre: "",
        abreviacion: "",
        descripcion: ""
    })

    const [estado, setEstado] = useState("deshabilitado")

    function handleFieldChange (fieldName, value) {
        setProtocoloActualizado((prevProtocolo) => ({
            ...prevProtocolo,
            [fieldName]: value
        }));
    };

    const referenciaModal = useRef(null);
    const modalBootstrap = useRef(null);

    async function actualizarProtocolo(){
        if(estado === "habilitado"){
            try {
                setEstado("cargando");
                //eliminar despues
                await new Promise(resolve => setTimeout(resolve, 2000));
                const response = await axios.put(`http://${IP}:${PUERTO_API}/protocolo/${protocolo._id}`,{
                    nombre: protocoloActualizado.nombre,
                    abreviacion: protocoloActualizado.abreviacion,
                    descripcion: protocoloActualizado.descripcion
                })
                
                setProtocolo(response.data);
                setProtocoloActualizado({
                    nombre: "",
                    abreviacion: "",
                    descripcion: ""
                })
                await modalBootstrap.current.hide();
                setEstado("habilitado");
            } catch (error) {
                console.log(error);
            }
        }
    }

    useEffect(() => {
        if(estado !== "cargando"){
            if (protocoloActualizado.nombre && protocoloActualizado.abreviacion) {
                setEstado("habilitado");
            } else {
                setEstado("deshabilitado");
            }
        }
    }, [protocoloActualizado]);
    
    useEffect(()=>{
        if(referenciaModal){
            modalBootstrap.current = new Modal(referenciaModal.current);
        }
    }, [referenciaModal])

    return (
        <div className="modal fade" id="editarProtocolo" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" ref={referenciaModal}>
            <div className="modal-dialog">
                <div className="modal-content">
                <div className="modal-header">
                    <h1 className="modal-title fs-5" id="exampleModalLabel">Editar protocolo</h1>
                    <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div className="modal-body">
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-12 mb-2">
                                <label htmlFor="nombreProtocoloActualizar" className="form-label" >Nombre del protocolo</label>
                                <input type="text" className="form-control" id="nombreProtocoloActualizar" aria-describedby="nombreProtocolo" placeholder="Ingrese aquí el nuevo nombre del protocolo." value={protocoloActualizado.nombre} onChange={(evento) => handleFieldChange("nombre", evento.target.value)}/>
                            </div>
                            <div className="col-6 mb-2">
                                <label htmlFor="abreviacionProtocoloActualizar" className="form-label" >Abreviacion del nombre</label>
                                <input type="text" className="form-control" id="abreviacionProtocoloActualizar" aria-describedby="nombreProtocolo" placeholder="Ingrese la abreviacion." value={protocoloActualizado.abreviacion}  onChange={(evento) => handleFieldChange("abreviacion", evento.target.value)} />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="descripcionProtocoloActualizar" className="form-label">Descripcion <span className="ho_fs_14 ho_color_soft_black">(opcional)</span></label>
                                <textarea className="form-control" id="descripcionProtocoloActualizar" rows="3" style={{resize: "none"}} value={protocoloActualizado.descripcion} onChange={(evento) => handleFieldChange("descripcion", evento.target.value)}></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="modal-footer">
                    <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" className="btn btn-primary ho_bg_blue" disabled={ estado !== "habilitado" } onClick={actualizarProtocolo}>
                        {
                            estado === "cargando"
                            ?
                            <>
                                <span className="spinner-border spinner-border-sm me-2" aria-hidden="true"></span>
                                <span role="status">Cargando...</span>
                            </>
                            :
                            "Aplicar cambios"
                        }
                    </button>
                </div>
                </div>
            </div>
        </div>
    );
}

export default ModalEditarProtocolo;