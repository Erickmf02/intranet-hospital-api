import { createContext, useContext, useState } from "react";
import ProtocoloItemCrear from "./protocoloItemCrear";
import {
    DndContext, 
    closestCenter,
    KeyboardSensor,
    useSensor,
    useSensors,
    DragOverlay,
    MouseSensor,
    TouchSensor,
} from '@dnd-kit/core';
import {
    arrayMove,
    SortableContext,
    verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { ContextoItems } from "../../pages/verProtocolo/verProtocolo";
import ProtocoloItem from "./protocoloItem";

export const ContextoEstadoBotonesDrag = createContext();
export const ContextoDrag = createContext();
export const ContextoActiveItem = createContext();

function DragContainer(){
    const {items, setItems} = useContext(ContextoItems)
    const [estadoBotonesDrag, setEstadoBotonesDrag] = useState("habilitado");
    const estadoEstadoBotonesDrag ={
        estadoBotonesDrag,
        setEstadoBotonesDrag,
    }

    const mouseSensor = useSensor(MouseSensor);
    const touchSensor = useSensor(TouchSensor);
    const keyboardSensor = useSensor(KeyboardSensor);
    const sensors = useSensors(
        mouseSensor,
        touchSensor,
        keyboardSensor,
    );

    const [isDraggingActive, setIsDraggingActive] = useState(false);
    const [activeItem, setActiveItem] = useState(null);

    const estadoDragging = {
        isDraggingActive,
        setIsDraggingActive
    }

    function handleDragEnd(evento){
        const {active, over} = evento;
        if ((active && over) && (active.id !== over.id)) {
            setItems((items) => {
                    const oldIndex = items.findIndex((item) => item._id === active.id);
                    const newIndex = items.findIndex((item) => item._id === over.id);
                    const updatedItems = arrayMove(items, oldIndex, newIndex).map((item, index)=>{
                        return {
                            ...item,
                            posicion: index + 1,
                        }
                    });
                    return updatedItems;
            });
        }
        setActiveItem(null);
    }
    function handleDragStart(evento){
        const { active } = evento;
        setActiveItem(items.find((item) => item._id == active.id));
    }
    function bajarOpacidad(item){
        return activeItem != null && activeItem._id === item._id;
    }

    return (
        <ContextoDrag.Provider value={estadoDragging}>
            <ContextoActiveItem.Provider value={activeItem}>
                <ContextoEstadoBotonesDrag.Provider value={estadoEstadoBotonesDrag}>
                    <DndContext onDragEnd={handleDragEnd} onDragStart={handleDragStart} collisionDetection={closestCenter} sensors={sensors}>
                        <SortableContext items={items.map(item => item._id)} strategy={verticalListSortingStrategy}>
                            <div className="row p-3 p-md-4 ho_bg_dark_white" >
                                    <ProtocoloItemCrear></ProtocoloItemCrear>
                                {items.map((item) =>(
                                    <ProtocoloItem key={item._id.toString()} item={item} opacar={ bajarOpacidad(item)}></ProtocoloItem>
                                ))}
                            </div>
                        </SortableContext>
                        <DragOverlay>
                            {activeItem ? (
                                <ProtocoloItem item={activeItem} opacar={false}></ProtocoloItem>
                            ): null}
                        </DragOverlay>
                    </DndContext>
                </ContextoEstadoBotonesDrag.Provider>
            </ContextoActiveItem.Provider>
        </ContextoDrag.Provider>
        
    );
}
export default DragContainer;