import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./navbar.css";
import logoHospital from "../pages/login/img/IMG_8840.png";
import { eliminarSesion } from "../utils";
function Navbar() {

  const navigate = useNavigate();

  function cerrarSecion(){
    eliminarSesion();
    navigate("/login")
  }
  
  return (
    <header className="navbar navbar-expand-md ho_navbar position-sticky top-0">
      <div className="container-fluid">
        <Link to="/" className="navbar-brand">
          <img className="ho_navbar_logo_hospital" src={logoHospital} alt="Logo del hospital de Mulchén." />
        </Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar_collapse_main" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbar_collapse_main">
          <nav className="d-flex justify-content-end w-100">
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link to={"/carpeta/65c0e8253e0395c1bf4454cd"} className="nav-link ho_fs_24">
                  Calidad
                </Link>
              </li>
              <li className="nav-item">
                <Link to={"/lista"} className="nav-link ho_fs_24">
                  Lista
                </Link>
              </li>
              <li className="nav-item">
                <Link to={"/perfil"} className="nav-link ho_fs_24">
                  Crear usuario
                </Link>
              </li>
              <li className="nav-item">
                <Link to={"/user"} className="nav-link ho_fs_24">
                  Usuario
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link ho_fs_24" onClick={cerrarSecion}>
                  Cerrar sesion
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </header>
  );
}

export default Navbar;
