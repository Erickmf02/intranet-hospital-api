export const IP = "192.168.0.104";
export const PUERTO_API = "3000";
export const URL_API = `http://${IP}:${PUERTO_API}`