/**
 * Guarda los datos de la sesión actual en el almacenamiento local del navegador.
 * @param {string} token - El token de autenticación de la sesión.
 * @param {string} id - El ID del usuario de la sesión.
 * @param {Array} roles - Los roles del usuario de la sesión.
 * @param {Date} fechaToken - La fecha de expiración del token de la sesión.
 * @returns {boolean} - Devuelve true si los datos de la sesión se guardaron correctamente, de lo contrario, devuelve false.
 */
export function guardarSesion(token, id, roles, fechaToken) {
    try {
        const datosSesionActual = { token, id, roles, fechaToken };
        localStorage.setItem("sesionActual", JSON.stringify(datosSesionActual));
        return true;
    } catch (error) {
        console.log(error);
        return false;
    }
}

/**
 * Obtiene los datos de la sesión actual del almacenamiento local del navegador.
 * @returns {Object|null} - Devuelve los datos de la sesión actual si están disponibles, de lo contrario, devuelve null.
 */
export function obtenerSesion() {
    try {
        const datosSesionString = localStorage.getItem("sesionActual");
        if (datosSesionString) {
            const datosSesion = JSON.parse(datosSesionString);
            return datosSesion;
        } else {
            return null;
        }
    } catch (error) {
        console.log(error);
        return null;
    }
}

/**
 * Elimina los datos de la sesión actual del almacenamiento local del navegador.
 * @returns {boolean} - Devuelve true si los datos de la sesión se eliminaron correctamente, de lo contrario, devuelve false.
 */
export function eliminarSesion() {
    try {
        localStorage.removeItem("sesionActual");
        return true;
    } catch (error) {
        console.log(error);
        return false;
    }
}

/**
 * Comprueba si un token está dentro del tiempo de validez especificado.
 * @param {Date} fecha - La fecha del token.
 * @param {number} segundos - La cantidad de segundos de validez del token.
 * @returns {boolean} - Devuelve true si el token está dentro del tiempo de validez especificado, de lo contrario, devuelve false.
 */
export function tokenEnFecha(fecha, segundos) {
    const fechaToken = new Date(fecha);
    const fechaActual = new Date();

    const diferenciaTiempo = fechaActual - fechaToken;
    const diferenciaSegundos = diferenciaTiempo / 1000;

    return diferenciaSegundos <= segundos;
}

/**
 * Comprueba si hay un token de sesión almacenado en el almacenamiento local del navegador.
 * @returns {boolean} - Devuelve true si hay un token de sesión almacenado, de lo contrario, devuelve false.
 */
export function tieneToken() {
    const sesion = obtenerSesion();

    if (!sesion) {
        return false;
    }

    const { token } = sesion;

    return !!token;
}

/**
 * Comprueba la validez del token de sesión actual y redirige a la página de inicio de sesión si es necesario.
 */
export function tieneTokenEnFecha() {
    const datosSesion = obtenerSesion();
    if (!datosSesion) return false;

    const { token, fechaToken } = datosSesion;
    if(!token || !fechaToken) return false;

    const estaEnFecha = tokenEnFecha(fechaToken, 60 * 60 * 24);
    return estaEnFecha;
}

/**
 * Comprueba si el usuario tiene permisos sobre una carpeta específica.
 * @param {Object} carpetaObjeto - El objeto de la carpeta sobre la que se comprueban los permisos.
 * @returns {boolean} - Devuelve true si el usuario tiene permisos sobre la carpeta, de lo contrario, devuelve false.
 */
export function tienePermisosSobreCarpeta(carpetaObjeto) {
    try {
        const sesion = obtenerSesion();
        if (!sesion) return false;

        const { id } = sesion;

        const esAdmin = tienePermisosDeAdministrador();

        if (esAdmin) return true;

        return usuarioEsAdministradorEnCarpeta(id, carpetaObjeto);
    } catch (error) {
        console.error(error);
        return false;
    }
}

/**
 * Verifica si el usuario es administrador de una carpeta recursivamente.
 * @param {string} usuarioId - El ID del usuario.
 * @param {Object} carpetaObjeto - El objeto de la carpeta.
 * @returns {boolean} - Devuelve true si el usuario es administrador de la carpeta, de lo contrario, devuelve false.
 */
function usuarioEsAdministradorEnCarpeta(usuarioId, carpetaObjeto) {
    const { administradores, padre } = carpetaObjeto;

    if (administradores.some(admin => admin._id == usuarioId)) {
        return true;
    }

    if (!padre) {
        return false;
    }

    return usuarioEsAdministradorEnCarpeta(usuarioId, padre);
}

/**
 * Comprueba si el usuario tiene permisos de administrador.
 * @returns {boolean} - Devuelve true si el usuario tiene permisos de administrador, de lo contrario, devuelve false.
 */
export function tienePermisosDeAdministrador() {
    const sesion = obtenerSesion();
    if (!sesion) return false;
    const { roles } = sesion;
    return roles.some(rol => rol._id === "000000000000000000000001");
}
