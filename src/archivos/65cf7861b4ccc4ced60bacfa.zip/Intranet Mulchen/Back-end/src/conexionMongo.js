import mongoose from "mongoose";

const MONGO_DB_URL = "mongodb://erick:password@mongo:27017/bd?authSource=admin";
const MONGO_DB_URL_DEV = "mongodb://adminTestdb:admin@127.0.0.1:27017/testdb?authSource=admin";

async function conectarABaseDeDatos() {
    try {
        await mongoose.connect(MONGO_DB_URL);

    console.log("Conexión exitosa a MongoDB");
    } catch (error) {
        console.error("Error de conexión a MongoDB:", error.message);
    }
}
async function conectarABaseDeDatosDev() {
    try {
        await mongoose.connect(MONGO_DB_URL_DEV);

    console.log("Conexión exitosa a MongoDB");
    } catch (error) {
        console.error("Error de conexión a MongoDB:", error.message);
    }
}
export {conectarABaseDeDatosDev};
export default conectarABaseDeDatos;