import express from "express"
import { obtenerProtocolos, obtenerProtocoloPorId, crearProtocolo, actualizarProtocolo, eliminarProtocolo } from "../controller/controlador.protocolo.js";

const routerProtocolo = express.Router()

routerProtocolo.get("/", obtenerProtocolos);
routerProtocolo.get("/:id", obtenerProtocoloPorId);
routerProtocolo.post("/", crearProtocolo);
routerProtocolo.put("/:id", actualizarProtocolo);
routerProtocolo.delete("/:id", eliminarProtocolo);

export default routerProtocolo;