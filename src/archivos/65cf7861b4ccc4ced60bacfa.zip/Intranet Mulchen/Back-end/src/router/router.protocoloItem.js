import express from "express";
import multer from "multer";
import {
    crearProtocoloItem,
    obtenerArchivo,
    actualizarProtocoloItem,
    eliminarProtocoloItem,
    verProtocoloItemPorId,
    verTodosProtocoloItems,
    verProtocoloItemsPorProtocoloId,
    actualizarPosiciones
} from "../controller/controlador.protocoloItem.js";

// Configuración de Multer para el manejo de archivos
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'src/archivos/');
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now());
    },
});

const upload = multer({ storage: storage });

const routerProtocoloItem = express.Router();

// Rutas CRUD

// Create
routerProtocoloItem.post("/", upload.single("archivo"), crearProtocoloItem);

// Read
routerProtocoloItem.get("/:id/archivo", obtenerArchivo);
routerProtocoloItem.get("/:id", verProtocoloItemPorId);
routerProtocoloItem.get("/", verTodosProtocoloItems);
routerProtocoloItem.get("/:id/protocolo", verProtocoloItemsPorProtocoloId);

// Update
routerProtocoloItem.put("/actualizar_posiciones", actualizarPosiciones);
routerProtocoloItem.put("/:id", upload.single("archivo"), actualizarProtocoloItem);

// Delete
routerProtocoloItem.delete("/:id", eliminarProtocoloItem);

export default routerProtocoloItem;
