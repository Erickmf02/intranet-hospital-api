import express from "express";
import {actualizarArchivo, agregarArchivo,obtenerArchivo,ordenarArchivos,verArchivo,verArchivosCarpeta,verArchivosCarpetaPorId, eliminarArchivoCarpeta } from "../controller/controlador.archivosCarpeta.js";
import multer from "multer";

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'src/archivos/');
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now());
    },
});

const upload = multer({ storage: storage });


const routerArchivosCarpeta = express.Router();

routerArchivosCarpeta.get("/:id/:archivoId/archivo", obtenerArchivo);
routerArchivosCarpeta.get("/:id/:archivoId", verArchivo);
routerArchivosCarpeta.get("/:id",verArchivosCarpetaPorId)
routerArchivosCarpeta.get("/", verArchivosCarpeta);

routerArchivosCarpeta.post("/add/:id", upload.single("archivo"), agregarArchivo);

routerArchivosCarpeta.put("/ordenar/:id", ordenarArchivos);
routerArchivosCarpeta.put("/:id/:idItem", upload.single("archivo"), actualizarArchivo);

routerArchivosCarpeta.delete("/:id/:archivoId", eliminarArchivoCarpeta);

export default routerArchivosCarpeta;