import Protocolo from "../model/protocolo.js";
import ProtocoloItem from "../model/protocoloItem.js";
import { eliminarProtocoloItemPorId } from "./controlador.protocoloItem.js";

async function obtenerProtocolos (req, res) {
    try {
        const protocolos = await Protocolo.find();
        res.status(200).json(protocolos);
    } catch (error) {
        console.error("Error en obtenerProtocolos(", error);
        res.status(500).json({ error: "Error interno del servidor" });
    }
};

async function obtenerProtocoloPorId (req, res) {
    try {
        const { id } = req.params;
        if( !id ){
            return res.status(400).json({error: "El id es obligatorio."})
        }

        const protocolo = await Protocolo.findById(id);

        if (!protocolo) {
            return res.status(404).json({ error: "Protocolo no encontrado." });
        }

        res.status(200).json(protocolo);
    } catch (error) {
        console.error("Error en obtenerProtocoloPorId()", error);
        res.status(500).json({ error: "Error interno del servidor." });
    }
};

const crearProtocolo = async (req, res) => {
    try {
        const { nombre, abreviacion, descripcion } = req.body;

        if( !nombre || !abreviacion ){
            return res.status(400).json({error: "El nombre o abreviación son obligatorios."})
        }
        
        const nuevoProtocolo = await Protocolo.create({
            nombre,
            abreviacion,
            descripcion,
        })
        
        res.status(201).json(nuevoProtocolo);
    } catch (error) {
        console.error("Error en crearProtocolo", error);
        res.status(500).json({ error: "Error interno del servidor." });
    }
};

const actualizarProtocolo = async (req, res) => {
    try {
        const { id } = req.params;

        if(!id){
            return res.status(400).json({error: "El id es obligatorio."});
        }
        const { nombre, abreviacion, descripcion } = req.body;

        let protocolo = await Protocolo.findById(id);

        if (!protocolo) {
            return res.status(404).json({ error: "Protocolo no encontrado." });
        }

        let cambiosRealizados = false;

        if (nombre !== undefined && nombre !== null && nombre !== "") {
            protocolo.nombre = nombre;
            cambiosRealizados = true;
        }

        if (abreviacion !== undefined && abreviacion !== null && abreviacion !== "") {
            protocolo.abreviacion = abreviacion;
            cambiosRealizados = true;
        }

        if (descripcion !== undefined && descripcion !== null && abreviacion !== "") {
            protocolo.descripcion = descripcion;
            cambiosRealizados = true;
        }

        if(cambiosRealizados){
            protocolo = await protocolo.save();
        }

        res.status(200).json(protocolo);
    } catch (error) {
        console.error("Error al actualizar el protocolo:", error.message);
        res.status(500).json({ error: "Error interno del servidor" });
    }
};

const eliminarProtocolo = async (req, res) => {
    try {
        const { id } = req.params;

        if(!id){
            return res.status(400).json({error: "El id es obligatorio."});
        }

        const protocolo = await Protocolo.findById(id);

        if (!protocolo) {
            return res.status(404).json({ error: "Protocolo no encontrado" });
        }

        const protocoloItems = await ProtocoloItem.find({protocolo: protocolo._id});

        for (const protocoloItem of protocoloItems) {
            const resultado = await eliminarProtocoloItemPorId(protocoloItem._id);
            if(!resultado.success){
                console.log("error", resultado.error);
                console.log("archivo eliminado?", resultado.eliminacionExitosa);
            }
        }

        await Protocolo.findByIdAndDelete(protocolo._id);

        res.status(200).json({success: true});
    } catch (error) {
        console.error("Error en eliminarProtocolo", error);
        res.status(500).json({ error: "Error interno del servidor" });
    }
};

export { obtenerProtocolos, obtenerProtocoloPorId, crearProtocolo, actualizarProtocolo, eliminarProtocolo };
