import ArchivosCarpeta from "../model/archivosCarpeta.js";
import mime from "mime";
import mongoose from "mongoose";
import moment from "moment-timezone"
import { leerArchivo, eliminarArchivo, renombrarArchivo } from "../utils/archivos.js";

export async function obtenerArchivo(req, res) {
    try {
        const { id, archivoId } = req.params;

        if( !id || !archivoId ) return res.status(400).json({error: "El id es obligatorio."})

        const archivoCarpeta = await ArchivosCarpeta.findOne({protocolo: id});
        if (!archivoCarpeta) return res.status(404).send(`El archivo carpeta no existe`);

        const archivo = archivoCarpeta.archivos.find((archivo) => archivo._id.toString() === archivoId);

        if (!archivo) return res.status(404).send(`El archivo con id ${archivoId} no fue encontrado`);

        const rutaArchivo = archivo.rutaArchivo;
        
        const contenidoArchivo = await leerArchivo(rutaArchivo);
        if (!contenidoArchivo) return res.status(500).send(`Se produjo un error leyendo el archivo`);

        const {titulo} = archivo;
        const {extension, mimetype} = obtenerDatosAdicionales(rutaArchivo);
        
        res.setHeader('Content-Type', mimetype);

        const esAudioOVideo = ['mp3', 'ogg', 'wav', 'mp4', 'webm', 'ogg'].includes(extension);

        if (esAudioOVideo) {
            res.setHeader('Content-Disposition', `attachment; filename="${titulo}.${extension}"`);
        } else {
            res.setHeader('Content-Disposition', `inline; filename="${titulo}.${extension}"`);
        }

        res.send(contenidoArchivo);
    } catch (error) {
        console.error("Error al obtener el archivo:", error);
        res.status(500).send('Error al obtener el archivo');
    }
}

export async function verArchivosCarpeta(req, res){
    try {
        const archivosCarpetas = await ArchivosCarpeta.find();
        
        const respuesta = [];
        for (const archivosCarpeta of archivosCarpetas) {
            respuesta.push(prepararParaEnviar(archivosCarpeta))
        }
        return res.status(200).json(respuesta); 
    } catch (error) {
        console.log(error);
        return res.status(500).json({ error: 'Error interno del servidor' });
    }
}

export async function verArchivosCarpetaPorId(req, res){
    try {
        const {id} = req.params;
        const archivosCarpeta = await ArchivosCarpeta.findOne({carpeta: id}).populate("carpeta");

        if (!archivosCarpeta) {
            return res.status(404).json({ error: 'Documento no encontrado' });
        }

        const respuesta = prepararParaEnviar(archivosCarpeta);

        return res.status(200).json(respuesta); 
    } catch (error) {
        console.log(error);
        return res.status(500).json({ error: 'Error interno del servidor' });
    }
}

export async function verArchivo(req, res){
    try {
        const {id, archivoId} = req.params;
        const archivosCarpeta = await ArchivosCarpeta.findOne({carpeta: id});

        if (!archivosCarpeta) {
            return res.status(404).json({ error: 'Documento no encontrado' });
        }

        const archivo = archivosCarpeta.archivos.find(archivo => archivo._id.toString() === archivoId);
        
        if (!archivo) {
            return res.status(404).json({ error: 'archivo no encontrado' });
        }

        const { extension, mimetype } = obtenerDatosAdicionales(archivo.rutaArchivo);
        const respuesta = {
            ...archivo._doc,
            extension,
            mimetype
        }
        return res.status(200).json(respuesta); 
    } catch (error) {
        console.log(error);
        return res.status(500).json({ error: 'Error interno del servidor' });
    }
}

export async function agregarArchivo(req, res){
    try {
        const { file, body, params } = req;

        if (!file || !params.id || !body.titulo) {
            return res.status(400).json({ error: "El título, id o archivo son obligatorios." });
        }

        const { filename, mimetype, originalname } = file;
        const { id } = params;
        const { titulo } = body;

        const archivosCarpeta = await ArchivosCarpeta.findOne({carpeta: id});

        if (!archivosCarpeta) {
            return res.status(404).json({ error: 'Documento no encontrado' });
        }

        
        const archivoId = new mongoose.Types.ObjectId();

        //const fecha =  moment().tz('America/Santiago').format("YYYY-MM-DDTHH:mm:ss.SSS[Z]");
        //para obtener la fecha en hora santiago usar ToISOString(true).
        const fecha = moment().tz("America/Santiago").toISOString();

        const archivo = {
            _id: archivoId,
            titulo,
            ultimaActualizacion: fecha,
            fechaSubida: fecha,
        };

        archivosCarpeta.archivos.unshift(archivo);

        const updatedArchivosCarpeta = await archivosCarpeta.save();

        const ultimoPuntoIndex = originalname.lastIndexOf(".");
        const extension = ultimoPuntoIndex !== -1 ? originalname.slice(ultimoPuntoIndex + 1) : '';  

        const archivoIndex = updatedArchivosCarpeta.archivos.findIndex((archivo) => archivo._id === archivoId);

        const nuevoArchivo = updatedArchivosCarpeta.archivos[archivoIndex];

        const nuevoNombreArchivo = `${nuevoArchivo._id}.${extension}`;

        const renombrarExitoso = await renombrarArchivo(filename,nuevoNombreArchivo)

        if(!renombrarExitoso){
            res.status(500).json({ error: "Error renombrando archivo" });
        }

        nuevoArchivo.rutaArchivo = `src/archivos/${nuevoNombreArchivo}`;

        updatedArchivosCarpeta.archivos.splice(archivoIndex, 1, nuevoArchivo);
        await updatedArchivosCarpeta.save();

        const respuesta = {
            ...nuevoArchivo._doc,
            extension,
            mimetype
        }

        return res.status(200).json(respuesta); 
    } catch (error) {
        console.log(error);
        return res.status(500).json({ error: 'Error interno del servidor' });
    }
}

export async function actualizarArchivo(req, res) {
    try {
        const { file, body, params } = req;

        if (!params.id || !params.archivoId) {
            return res.status(400).json({ error: "id , archivoId son obligatorios." });
        }

        const { id, archivoId } = params;
        const { titulo } = body;

        const archivosCarpeta = await ArchivosCarpeta.findOne({ carpeta: id });

        if (!archivosCarpeta) {
            return res.status(404).json({ error: 'Documento no encontrado' });
        }

        const archivoIndex = archivosCarpeta.archivos.findIndex(archivo => archivo._id.toString() === archivoId);

        if (archivoIndex === -1) {
            return res.status(404).json({ error: 'archivo no encontrado' });
        }

        const archivo = archivosCarpeta.archivos[archivoIndex];

        let cambiosRealizados = false;

        if( file ){

            const eliminacionExitosa = await eliminarArchivo(archivo.rutaArchivo);

            if(!eliminacionExitosa){
                console.log(`error eliminando el archivo de ruta: ${archivo.rutaArchivo}`)
            }
            
            const { filename, originalname } = file;

            const ultimoPuntoIndex = originalname.lastIndexOf(".");
            const extension = ultimoPuntoIndex !== -1 ? originalname.slice(ultimoPuntoIndex + 1) : '';
            
            const nuevoNombreArchivo = `${archivo._id}.${extension}`;

            const renombrarExitoso = await renombrarArchivo(filename,nuevoNombreArchivo)
            if(!renombrarExitoso){
                res.status(500).json({ error: "Error renombrando archivos" });
            }

            archivo.rutaArchivo = `src/archivos/${nuevoNombreArchivo}`;

            cambiosRealizados = true;
        }

        if(titulo){
            archivo.titulo = titulo;
            cambiosRealizados = true;
        }

        if(cambiosRealizados){
            const fecha = moment().tz("America/Santiago").toISOString();
            archivo.ultimaActualizacion = fecha;
            archivosCarpeta.items.splice(indexItem, 1, item);
            await archivosCarpeta.save();
        }

        const { extension, mimetype } = obtenerDatosAdicionales(archivo.rutaArchivo) 
        const respuesta = {
            ...archivo._doc,
            extension,
            mimetype
        }
        return res.status(200).json(respuesta);
    } catch (error) {
        console.log(error);
        return res.status(500).json({ error: 'Error interno del servidor' });
    }
}

export async function ordenarArchivos(req, res) {
    try {
        const { id } = req.params;
        const { orden } = req.body;

        const archivosCarpeta = await ArchivosCarpeta.findOne({ carpeta: id });

        if (!archivosCarpeta) {
            return res.status(404).json({ error: 'Documento no encontrado' });
        }

        archivosCarpeta.archivos.sort((a, b) => {
            return orden.indexOf(a._id.toString()) - orden.indexOf(b._id.toString());
        });

        await archivosCarpeta.save();

        const respuesta = prepararParaEnviar(archivosCarpeta);

        return res.status(200).json(respuesta);
    } catch (error) {
        console.log(error);
        return res.status(500).json({ error: 'Error interno del servidor' });
    }
}

export async function eliminarArchivoCarpeta(req, res) {
    try {
        const { id, archivoId } = req.params;

        const archivosCarpeta = await archivosCarpeta.findOne({ carpeta: id });

        if (!archivosCarpeta) {
            return res.status(404).json({ error: 'Documento no encontrado' });
        }

        const archivoIndex = archivosCarpeta.archivos.findIndex(archivo => archivo._id.toString() === archivoId);

        if (archivoIndex === -1) {
            return res.status(404).json({ error: 'archivo no encontrado' });
        }

        const archivo = archivosCarpeta.archivos[archivoIndex];

        const eliminadoExitoso = await eliminarArchivo(archivo.rutaArchivo);

        if(!eliminadoExitoso){
            console.log("error eliminando");
        }

        archivosCarpeta.archivos.splice(archivoIndex, 1);
        await archivosCarpeta.save();

        const respuesta = prepararParaEnviar(archivosCarpeta);

        return res.status(200).json(respuesta);
    } catch (error) {
        console.log(error);
        return res.status(500).json({ error: 'Error interno del servidor' });
    }
}

function prepararParaEnviar(archivosCarpeta){
    const archivosRellenos = [];
    for (const archivo of archivosRellenos.archivos) {

        const {extension, mimetype} = obtenerDatosAdicionales(archivo.rutaArchivo);

        const archivoRelleno = {
            ...archivo._doc,
            extension,
            mimetype
        }
        archivosRellenos.push(archivoRelleno);
    }
    const nuevoProtocoloItemRelleno = {
        ...archivosCarpeta._doc,
        archivos: archivosRellenos
    }
    return nuevoProtocoloItemRelleno;
}

function obtenerDatosAdicionales(rutaArchivo){
    const nombreArchivo = rutaArchivo.split('/').pop();
    const extension = nombreArchivo.split(".").pop();
    const mimetype = mime.getType(extension);

    return { extension, mimetype};
}

