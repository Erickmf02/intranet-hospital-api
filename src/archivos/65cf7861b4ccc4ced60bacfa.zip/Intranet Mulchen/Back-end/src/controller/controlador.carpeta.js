import Carpeta from "../model/carpeta.js";
import Archivo from "../model/archivo.js";
import Usuario from "../model/usuario.js";
import * as serverFiles from "../utils/archivos.js";
import moment from "moment-timezone"
import { usuarioEsAdministrador } from "../utils/roles.js";

const tipos = ["archivos", "carpetas"];

export async function verCarpetas(req, res){
    try {
        const carpetas = await Carpeta.find()
            .populate({
                path: "administradores",
                select: "-password",
                populate: {
                    path: "roles"
                }
            })
            .populate("archivos")
            .populate({
                path: "hijos",
                select: "-padre",
                populate: {
                    path: "administradores",
                    select: "-password",
                    populate: "roles"
                }
            });
        
        const carpetasFormateadas = await Promise.all(carpetas.map(async (carpeta) => {
            const carpetaObjeto = carpeta.toObject();
            carpetaObjeto.padre = await popularPadresRecursivamente(carpeta.padre);
            return carpetaObjeto;
        }));

        res.status(200).json(carpetasFormateadas);
    } catch (error) {
        console.error("Error en verCarpetas", error);
        res.status(500).json({ error: "Error interno del servidor." });
    }
}

export async function verCarpetaPorId(req, res){
    try {
        const carpetaHomeId = "100000000000000000000001";

        let { id } = req.query;
        id = id ? id : carpetaHomeId;

        const carpeta = await Carpeta.findById(id).populate([
            {
                path: "administradores",
                select: "-password",
                populate:{
                    path: "roles"
                }
            },
            {
                path: "archivos"
            },
            {
                path: "hijos",
                select: "-padre",
                populate: {
                    path: "administradores",
                    select: "-password",
                    populate: {
                        path: "roles"
                    }
                }
            }
        ])

        if(!carpeta){
            return res.status(400).json({error: `la carpeta id: ${id} no existe`})
            
        }

        const objeto = carpeta.toObject();

        objeto.padre = await popularPadresRecursivamente(carpeta.padre)

        res.status(200).json(objeto);
    } catch (error) {
        console.error("Error en verCarpetaPorId", error);
        res.status(500).json({ error: "Error interno del servidor." });
    }
}

export async function crearCarpeta(req, res){
    try {
        //validaciones
        const { padre, nombre, tipo, conPortada, descripcion } = req.body;
        const { usuario } = req;

        if( !padre || !nombre || !tipo ){
            return res.status(400).json({error: "El padre, nombre y tipo es obligatorios."})
        }

        if(!tipos.includes(tipo)){
            return res.status(400).json({error: `Solo los tipos "archivos" y "carpetas" son validos`})
        }

        const carpetaPadre = await Carpeta.findById(padre)
            .populate({
                path: "administradores",
                select: "-password"
            });

        if (!carpetaPadre) {
            return res.status(404).json({ error: "Carpeta padre no encontrada." });
        }

        const carpetaPadreObjeto = carpetaPadre.toObject();
        carpetaPadreObjeto.padre = await popularPadresRecursivamente(carpetaPadre._id);

        const tienePermisos = tienePermisosSobreCarpeta(usuario, carpetaPadreObjeto);

        if(!tienePermisos) return res.status(400).json({error: `No tienes los permisos necesarios para crear una carpeta, dentro de la carpeta ${carpetaPadre.nombre}.`});

        //crear carpeta
        const carpeta = {
            nombre,
            tipo,
            padre : carpetaPadre._id,
        }

        if(conPortada == true){
            if(!descripcion){
                return res.status(400).json({error: "La descripcion es obligatoria en carpetas con portada."})
            }
            carpeta.conPortada = true;
            carpeta.descripcion = descripcion;
        }

        const nuevaCarpeta = await Carpeta.create(carpeta);
        carpetaPadre.hijos.unshift(nuevaCarpeta._id);
        await carpetaPadre.save();
        
        const respuesta = {
            ...nuevaCarpeta._doc,
            padre: await popularPadresRecursivamente(nuevaCarpeta.padre)
        }

        res.status(201).json(respuesta);
    } catch (error) {
        console.error("Error en crearCarpeta", error);
        res.status(500).json({ error: "Error interno del servidor." });
    }
}

export async function editarCarpeta(req, res) {
    try {
        const { id } = req.params;
        const { usuario } = req;
        const { nombre, administradores, tipo, conPortada, descripcion} = req.body;

        const carpeta = await Carpeta.findById(id)
            .populate({
                path: "administradores",
                select: "-password"
            })
            .populate("archivos")
            .populate({
                path: "hijos",
                select: "-padre",
                populate: {
                    path: "administradores",
                    select: "-password",
                    populate: "roles"
                }
            });

        if (!carpeta) return res.status(404).json({ error: "Carpeta no encontrada." });
        
        let carpetaObjeto = carpeta.toObject();

        carpetaObjeto.padre = await popularPadresRecursivamente(carpeta.padre);

        const tienePermisos = tienePermisosSobreCarpeta(usuario, carpetaObjeto);

        if(!tienePermisos) return res.status(400).json({error: `No tienes los permisos necesarios para crear una carpeta, dentro de la carpeta ${carpeta.nombre}.`});
        //edicion
        let cambiosRealizados  = false;

        if(nombre){
            carpeta.nombre = nombre;
            cambiosRealizados  = true;
        }

        if (conPortada !== undefined || conPortada !== null) {
            if (conPortada) {
                if (!descripcion) {
                    return res.status(400).json({ error: "La descripción es obligatoria en carpetas con portada." });
                }
                carpeta.conPortada = true;
                carpeta.descripcion = descripcion;
            } else {
                carpeta.conPortada = false;
                carpeta.descripcion = null;
            }
            cambiosRealizados = true;
        }

        

        if (administradores) {
            for (const usuarioId of administradores) {
                const usuario = await Usuario.findById(usuarioId);
                if (!usuario) {
                    return res.status(404).json({ error: "Uno de los usuarios es inexistente." });
                }
            }
            carpeta.administradores = administradores;
            cambiosRealizados = true;
        }

        if (tipo && carpeta.tipo !== tipo) {
            if (!tipos.includes(tipo)) {
                return res.status(400).json({ error: `El tipo "${tipo}" no es válido. Solo se permiten los tipos "archivos" y "carpetas".` });
            }
            if (carpeta.tipo === "carpetas") {
                await eliminarCarpetasHijas(carpeta);
            } else if (carpeta.tipo === "archivos") {
                await eliminarArchivosDeCarpeta(carpeta);
            }
            carpeta.tipo = tipo;
            cambiosRealizados = true;
        }

        if(cambiosRealizados){
            carpeta.fechaActualizacion = new Date();
            await carpeta.save();
            
        }
        await carpeta.populate({
            path: "administradores",
            select: "-password",
            populate: {
                path: "roles"
            }
        });
        
        carpetaObjeto = carpeta.toObject();

        carpetaObjeto.padre = await popularPadresRecursivamente(carpeta.padre);

        res.status(200).json(carpetaObjeto);
    } catch (error) {
        console.error("Error en editarCarpeta", error);
        res.status(500).json({ error: "Error interno del servidor." });
    }
}

export async function eliminarCarpeta(req, res) {
    try {
        const { id } = req.params;
        const { usuario } = req;

        const carpeta = await Carpeta.findById(id)
            .populate({
                path: "administradores",
                select: "-password",
                populate: {
                    path: "roles"
                }
            });

        if (!carpeta) {
            return res.status(404).json({ error: "Carpeta no encontrada." });
        }

        const carpetaObjeto = carpeta.toObject();

        carpetaObjeto.padre = popularPadresRecursivamente(carpeta.padre);

        const tienePermisos = tienePermisosSobreCarpeta(usuario, carpetaObjeto);

        if(!tienePermisos) return res.status(400).json({error: `No tienes los permisos necesarios para crear una carpeta, dentro de la carpeta ${carpeta.nombre}.`});

        const carpetaEliminada = await eliminarCarpetaRecursiva(carpeta._id)

        res.status(200).json({ carpeta: carpetaEliminada });
    } catch (error) {
        console.error("Error en eliminarCarpeta", error);
        res.status(500).json({ error: "Error interno del servidor." });
    }
}

//archivos

export async function verContenidoArchivo(req, res) {
    try {
        const { id } = req.params;

        if( !id ){
            return res.status(400).json({error: "El id es obligatorio."})
        }
        const archivo = await Archivo.findById(id);

        if (!archivo) {
            return res.status(404).send(`El archivo con id ${id} no fue encontrado`);
        }

        const rutaArchivo = archivo.ruta;
        console.log(rutaArchivo)
        
        const contenidoArchivo = await serverFiles.leerArchivo(rutaArchivo);
        if (!contenidoArchivo){
            return res.status(500).send(`Se produjo un error leyendo el archivo`);
        }
        const {titulo} = archivo;
        const {extension, mimetype} = serverFiles.obtenerDatosAdicionales(rutaArchivo);
        
        res.setHeader('Content-Type', mimetype);

        const esAudioOVideo = ['mp3', 'ogg', 'wav', 'mp4', 'webm', 'ogg'].includes(extension);

        if (esAudioOVideo) {
            res.setHeader('Content-Disposition', `attachment; filename="${titulo}.${extension}"`);
        } else {
            res.setHeader('Content-Disposition', `inline; filename="${titulo}.${extension}"`);
        }

        res.send(contenidoArchivo);
    } catch (error) {
        console.error("Error al obtener el archivo:", error);
        res.status(500).send('Error al obtener el archivo');
    }
}

export async function agregarArchivo(req, res){
    try {
        const { file, body, params } = req;

        if (!file || !params.id || !body.nombre) {
            return res.status(400).json({ error: "El título, id o archivo son obligatorios." });
        }

        const { filename, mimetype, originalname } = file;
        const { id } = params;
        const { nombre } = body;

        const carpeta = await Carpeta.findById(id).populate({
            path: "administradores",
            select: "-password",
            populate: {
                path: "roles"
            }
        });

        if (!carpeta) {
            return res.status(404).json({ error: 'Carpeta no encontrada' });
        }

        if(carpeta.tipo != "archivos"){
            return res.status(400).json({ error: "Esta carpeta no puede contener archivos" });
        }

        //const fecha =  moment().tz('America/Santiago').format("YYYY-MM-DDTHH:mm:ss.SSS[Z]");
        //para obtener la fecha en hora santiago usar ToISOString(true).
        const fecha = moment().tz("America/Santiago").toISOString();

        const archivo = await Archivo.create({
            carpeta: carpeta._id,
            nombre,
            fechaActualizacion: fecha,
            fechaSubida: fecha,
        })

        const ultimoPuntoIndex = originalname.lastIndexOf(".");
        const extension = ultimoPuntoIndex !== -1 ? originalname.slice(ultimoPuntoIndex + 1) : '';  

        const nuevoNombreArchivo = `${archivo._id}.${extension}`;

        const renombrarExitoso = await serverFiles.renombrarArchivo(filename,nuevoNombreArchivo)

        if(!renombrarExitoso){
            res.status(500).json({ error: "Error renombrando archivo" });
        }

        archivo.ruta = `src/archivos/${nuevoNombreArchivo}`;
        await archivo.save()
        
        carpeta.archivos.unshift(archivo);
        await carpeta.save();

        const respuesta = {
            ...archivo._doc,
            extension,
            mimetype
        }

        return res.status(200).json(respuesta); 
    } catch (error) {
        console.log(error);
        return res.status(500).json({ error: 'Error interno del servidor' });
    }
}

export async function editarArchivo(req, res) {
    try {
        const { file, body, params } = req;

        if (!params.id) {
            return res.status(400).json({ error: "id son obligatorios." });
        }

        const { id } = params;
        const { nombre } = body;

        const archivo = await Archivo.findById(id);;

        if(!archivo){
            return res.status(404).send(`El archivo con id ${id} no fue encontrado`);
        }
        let cambiosRealizados = false;

        if( file ){

            const eliminacionExitosa = await serverFiles.eliminarArchivo(archivo.ruta);

            if(!eliminacionExitosa){
                console.log(`error eliminando el archivo de ruta: ${archivo.ruta}`)
            }
            
            const { filename, originalname } = file;

            const ultimoPuntoIndex = originalname.lastIndexOf(".");
            const extension = ultimoPuntoIndex !== -1 ? originalname.slice(ultimoPuntoIndex + 1) : '';
            
            const nuevoNombreArchivo = `${archivo._id}.${extension}`;

            const renombrarExitoso = await serverFiles.renombrarArchivo(filename,nuevoNombreArchivo)
            if(!renombrarExitoso){
                res.status(500).json({ error: "Error renombrando archivos" });
            }

            archivo.ruta = `src/archivos/${nuevoNombreArchivo}`;

            cambiosRealizados = true;
        }

        if(nombre){
            archivo.nombre = nombre;
            cambiosRealizados = true;
        }

        if(cambiosRealizados){
            const fecha = moment().tz("America/Santiago").toISOString();
            archivo.fechaActualizacion = fecha;
            await archivo.save();
        }

        const { extension, mimetype } = serverFiles.obtenerDatosAdicionales(archivo.ruta) 
        const respuesta = {
            ...archivo._doc,
            extension,
            mimetype
        }
        return res.status(200).json(respuesta);
    } catch (error) {
        console.log(error);
        return res.status(500).json({ error: 'Error interno del servidor' });
    }
}

export async function ordenarArchivos(req, res) {
    try {
        const { id } = req.params;
        const { orden } = req.body;

        const carpeta = await Carpeta.findById(id);

        if (!carpeta) {
            return res.status(404).json({ error: 'Documento no encontrado' });
        }

        carpeta.archivos.sort((a, b) => {
            return orden.indexOf(a._id.toString()) - orden.indexOf(b._id.toString());
        });

        await carpeta.save();
        await carpeta.populate("archivos");

        const respuesta = {
            ...carpeta._doc,
            archivos: []
        };

        for (const archivo of carpeta.archivos) {
            const {extension, mimetype} = serverFiles.obtenerDatosAdicionales(archivo.ruta);
            respuesta.archivos.push({
                ...archivo._doc,
                extension,
                mimetype
            })
        }
        
        return res.status(200).json(respuesta);
    } catch (error) {
        console.log(error);
        return res.status(500).json({ error: 'Error interno del servidor' });
    }
}

export async function eliminarArchivo(req, res) {
    try {
        const { id } = req.params;

        if(!id){
            return res.status(400).json({ error: "id son obligatorios." });
        }

        const archivo = await Archivo.findById(id);

        if(!archivo){
            return res.status(404).send(`El archivo con id ${id} no fue encontrado`);
        }
        const carpeta = await Carpeta.findById(archivo.carpeta);

        if(!carpeta){
            return res.status(404).send(`el archivo no pertenece a ninguna carpeta`);
        }

        const archivoIndex = carpeta.archivos.findIndex(a => a.equals(archivo._id));

        if(archivoIndex != -1){
            carpeta.archivos.splice(archivoIndex, 1);
        }else{
            return res.status(404).send(`el archivo no pertenece a ninguna carpeta`);
        }

        const elimidadoDelContenidoExitoso = await serverFiles.eliminarArchivo(archivo.ruta);

        if(!elimidadoDelContenidoExitoso){
            console.log("error eliminando el archivo en el servidor");
        }

        const archivoEliminado = await Archivo.findByIdAndDelete(archivo._id);

        if(!archivoEliminado){
            return res.status(404).send(`no se pudo eliminar el archivo`);
        }

        await carpeta.save();

        const {extension, mimetype} = serverFiles.obtenerDatosAdicionales(archivoEliminado.ruta);

        const respuesta = {
            ...archivoEliminado._doc,
            extension,
            mimetype
        }

        return res.status(200).json(respuesta);
    } catch (error) {
        console.log(error);
        return res.status(500).json({ error: 'Error interno del servidor' });
    }
}
//extra
async function popularPadresRecursivamente(padreId) {
    try {
        const idCarpetaHome = "100000000000000000000001"

        if( !padreId || padreId == idCarpetaHome){
            return null;
        }

        const carpeta = await Carpeta.findById(padreId)
            .populate({
                path: "administradores",
                select: "-password",
                populate: {
                    path: "roles"
                }
            });
        
        const carpetaObjeto = carpeta.toObject();
        carpetaObjeto.padre = await popularPadresRecursivamente(carpeta.padre);

        return carpetaObjeto;
    } catch (error) {
        console.error("Error en popularPadresRecursivamente", error);
        return;
    }
}

async function eliminarCarpetaRecursiva(carpetaId) {
    try {
        const carpeta = await Carpeta.findById(carpetaId)
            .select("-nombre -fechaCreacion -fechaActualizacion -tipo -conPortada -descripcion")
            .populate([
                {
                    path: "archivos"
                },
                {
                    path: "padre",
                    select: "-nombre -fechaCreacion -fechaActualizacion -tipo -conPortada -descripcion -padre"
                }
            ]);

        for (const carpetaHija of carpeta.hijos) {
            await eliminarCarpetaRecursiva(carpetaHija);
        }

        for (const archivo of carpeta.archivos) {
            const eliminadoDelContenidoExitoso = await serverFiles.eliminarArchivo(archivo.ruta);

            if (!eliminadoDelContenidoExitoso) {
                console.log(`Error eliminando el archivo en el servidor: ${archivo.ruta}`);
            }

            await Archivo.findByIdAndDelete(archivo._id);
        }

        const padre = carpeta.padre;

        const carpetaEliminada = await Carpeta.findByIdAndDelete(carpeta._id);

        padre.hijos = padre.hijos.filter(hijo => hijo !== carpetaEliminada._id.toHexString());

        await padre.save();
        return carpetaEliminada;
    } catch (error) {
        console.error("Error en eliminarCarpetaRecursiva:", error);
        throw new Error("Error al eliminar la carpeta y su contenido.");
    }
}
function tienePermisosSobreCarpeta(usuario, carpetaObjeto){
    try {
        const esAdministrador = usuarioEsAdministrador(usuario);
        
        if(esAdministrador) return true;

        const esAdministradorDeCarpeta = usuarioEsAdministradorEnCarpeta(usuario, carpetaObjeto);
        
        return esAdministradorDeCarpeta;
    } catch (e) {
        console.log(e);
        return false;
    }
}

function usuarioEsAdministradorEnCarpeta(usuario, carpetaObjeto) {

    const { administradores } = carpetaObjeto;

    if (administradores.some(administrador => administrador._id.toHexString() === usuario._id.toHexString())) return true;
    
    if (carpetaObjeto.padre === null) return false;

    const carpetaPadre = carpetaObjeto.padre;
    
    return usuarioEsAdministradorEnCarpeta(usuario, carpetaPadre);
}