import fs from "fs/promises";
import ProtocoloItem from "../model/protocoloItem.js";
import Protocolo from "../model/protocolo.js";
import mime from "mime"

const ARCHIVOS_DIRECTORIO = "src/archivos/";

async function obtenerArchivo(req, res) {
    try {
        const { id } = req.params;

        if( !id ){
            return res.status(400).json({error: "El id es obligatorio."})
        }

        const protocoloItem = await ProtocoloItem.findById(id);
        if (!protocoloItem) {
            return res.status(404).send(`El protocolo item no existe`);
        }

        const rutaArchivo = protocoloItem.rutaArchivo;
        const contenidoArchivo = await leerArchivo(rutaArchivo);
        if (!contenidoArchivo){
            return res.status(500).send(`Se produjo un error leyendo el archivo`);
        }

        res.setHeader('Content-Type', protocoloItem.mimetype);

        const { extension, titulo } = protocoloItem;

        const esAudioOVideo = ['mp3', 'ogg', 'wav', 'mp4', 'webm', 'ogg'].includes(extension);

        if (esAudioOVideo) {
            res.setHeader('Content-Disposition', `attachment; filename="${titulo}.${extension}"`);
        } else {
            res.setHeader('Content-Disposition', `inline; filename="${titulo}.${extension}"`);
        }

        res.send(contenidoArchivo);
    } catch (error) {
        console.error("Error al obtener el archivo:", error);
        res.status(500).send('Error al obtener el archivo');
    }
}

async function verProtocoloItemPorId(req, res) {
    try {
        const { id } = req.params;

        if( !id ){
            return res.status(400).json({error: "El id es obligatorio."})
        }

        const protocoloItem = await ProtocoloItem.findById(id).populate('protocolo');

        if (!protocoloItem) {
            return res.status(404).json('ProtocoloItem no encontrado');
        }

        res.status(200).json(protocoloItem);
    } catch (error) {
        console.error("Error al obtener el ProtocoloItem por ID:", error.message);
        res.status(500).json({ error: "Error interno del servidor" });
    }
}

async function verTodosProtocoloItems(req, res) {
    try {
        const protocoloItems = await ProtocoloItem.find();
        res.status(200).json(protocoloItems);
    } catch (error) {
        console.error("Error al obtener todos los ProtocoloItems:", error.message);
        res.status(500).json({ error: "Error interno del servidor" });
    }
}

async function verProtocoloItemsPorProtocoloId(req, res) {
    try {
        const { id } = req.params;
        if( !id ){
            return res.status(400).json({error: "El id es obligatorio."})
        }

        const protocolo = await Protocolo.findById(id);

        if(!protocolo){
            return res.status(404).json({ error: "Protocolo no encontrado." });
        }

        const protocoloItems = await ProtocoloItem.find({ protocolo: protocolo._id });

        res.status(200).json(protocoloItems);
    } catch (error) {
        console.error("error en verProtocoloItemsPorProtocoloId", error);
        res.status(500).json({ error: "Error interno del servidor" });
    }
}

// Operaciones de Creación (Create)
async function crearProtocoloItem(req, res) {
    try {
        const { file, body } = req;
        const { id, titulo } = body;
        const { filename, mimetype, originalname } = file;

        if(!file || !id || !titulo){
            return res.status(400).json({error: "El titulo, id o archivo son obligatorios."})
        }

        await ProtocoloItem.updateMany({ protocolo: id }, { $inc: { posicion: 1 } });

        const ultimoPuntoIndex = originalname.lastIndexOf(".");
        const extension = ultimoPuntoIndex !== -1 ? originalname.slice(ultimoPuntoIndex + 1) : '';

        const fechaHoy = new Date();

        const nuevoItem = await ProtocoloItem.create({
            protocolo: id,
            titulo: titulo,
            posicion: 1,
            extension,
            mimetype,
            ultimaActualizacion: fechaHoy,
            fechaSubida: fechaHoy,
        });

        const nuevoNombreArchivo = `${nuevoItem._id}.${extension}`;

        const renombrarExitoso = await renombrarArchivo(filename,nuevoNombreArchivo)

        if(!renombrarExitoso){
            res.status(500).json({ error: "Error renombrando archivos" });
        }
        
        nuevoItem.rutaArchivo = `${ARCHIVOS_DIRECTORIO}${nuevoNombreArchivo}`;

        await nuevoItem.save();

        res.status(200).json(nuevoItem);
    } catch (error) {
        console.error("Error al crear el protocoloItem:", error);
        res.status(500).json({ error: "Error interno del servidor" });
    }
}

// Operaciones de Actualización (Update)
async function actualizarProtocoloItem(req, res) {
    try {
        const { file, params, body } = req;
        const { id } = params;
        const { titulo } = body;
        console.log(file)

        if( !id ){
            return res.status(400).json({error: "El id es obligatorio."})
        }

        const protocoloItem = await ProtocoloItem.findById(id);
        
        if (!protocoloItem) {
            return res.status(404).send('ProtocoloItem no encontrado');
        }
        
        let cambiosRealizados = false;

        if( file !== undefined && file !== null && file !== ""){

            const eliminacionExitosa = await eliminarArchivo(protocoloItem.rutaArchivo);

            if(!eliminacionExitosa){
                console.log(`error eliminando el archivo de ruta: ${protocoloItem.rutaArchivo}`)
            }
            
            const { filename, mimetype, originalname } = file;

            const ultimoPuntoIndex = originalname.lastIndexOf(".");
            const extension = ultimoPuntoIndex !== -1 ? originalname.slice(ultimoPuntoIndex + 1) : '';
            

            protocoloItem.extension = extension;
            protocoloItem.mimetype = mimetype;
            

            const nuevoNombreArchivo = `${protocoloItem._id}.${extension}`;
            const renombrarExitoso = await renombrarArchivo(filename,nuevoNombreArchivo)

            if(!renombrarExitoso){
                res.status(500).json({ error: "Error renombrando archivos" });
            }

            protocoloItem.rutaArchivo = `${ARCHIVOS_DIRECTORIO}${nuevoNombreArchivo}`;

            cambiosRealizados = true;
        }
        
        if(titulo !== undefined && titulo !== null && titulo !== ""){
            protocoloItem.titulo = titulo;
            cambiosRealizados = true;
        }
        
        
        if(cambiosRealizados){
            const fechaHoy = new Date();
            protocoloItem.ultimaActualizacion = fechaHoy;
            await protocoloItem.save();
        }

        res.status(200).json(protocoloItem);
    } catch (error) {
        console.error("Error al actualizar el protocoloItem:", error.message);
        res.status(500).json({ error: "Error interno del servidor" });
    }
}

async function actualizarPosiciones(req, res) {
    try {
        const {posiciones} = req.body;

        const posicionesUnicas = new Set();
        for (const nuevaPosicion of posiciones) {
            if (posicionesUnicas.has(nuevaPosicion.posicion)) {
                return res.status(400).json({ error: "Las posiciones deben ser únicas" });
            }
            posicionesUnicas.add(nuevaPosicion.posicion);
        }

        const protocoloItems = [];
        
        for (const nuevaPosicion of posiciones) {
            const protocoloItem = await ProtocoloItem.findById(nuevaPosicion._id);
            if (!protocoloItem) {
                return res.status(404).json({ error: `El item con _id ${nuevaPosicion._id} no existe` });
            }
            protocoloItems.push({protocoloItem: protocoloItem, posicion: nuevaPosicion.posicion});
        }

        await Promise.all(protocoloItems.map(async (itemMasPosicion) => {
            const { protocoloItem, posicion } = itemMasPosicion;
            protocoloItem.posicion = posicion;
            await protocoloItem.save();
        }));
        res.status(200).json({ success: true });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, error: "Error interno del servidor" });
    }
}

async function eliminarProtocoloItem(req, res) {
    try {
        const {id} = req.params;
        if(!id){
            return res.status(400).json({error: "El id es obligatorio."});
        }
        const resultado = await eliminarProtocoloItemPorId(id);
        if(!resultado.success){
            res.status(resultado.codigo).json({error: resultado.error});
        }
        res.status(200).json({success: resultado.success});
    } catch (error) {
        console.error("eliminarProtocoloItem", error);
        res.status(500).json({ error: "Error interno del servidor." });
    }
}
async function eliminarProtocoloItemPorId(id) {
    let eliminacionExitosa = false;
    try {
        if (!id) {
            return ({success: false, error: "El id es obligatorio.", codigo: 400, eliminacionExitosa})
        }

        const protocoloItem = await ProtocoloItem.findById(id);

        if (!protocoloItem) {
            return ({success: false, error: "El item del protocolo no se encontro.", codigo: 404, eliminacionExitosa})
        }
        
        eliminacionExitosa = eliminarArchivo(protocoloItem.rutaArchivo);
    
        await ProtocoloItem.findByIdAndDelete(id);

        return ({ success: true });
        
    } catch (error) {
        console.log(error)
        return ({success: false, error: "Error interno del servidor.", codigo: 500, eliminacionExitosa})
    }
}

export async function leerArchivo(rutaArchivo) {
    try {
        const contenidoArchivo = await fs.readFile(rutaArchivo, null);
        return contenidoArchivo;
    } catch (error) {
        console.error("Error al leer el archivo:", error);
        return null;
    }
}
export async function renombrarArchivo(archivoActual, nuevoNombre) {
    try {
        const rutaActual = `${ARCHIVOS_DIRECTORIO}${archivoActual}`;
        const rutaNuevoArchivo = `${ARCHIVOS_DIRECTORIO}${nuevoNombre}`;

        await fs.rename(rutaActual, rutaNuevoArchivo);
        return true;
    } catch (error) {
        console.error("Error al renombrar el archivo:", error);
        return false;
    }
}
export async function eliminarArchivo(rutaArchivo) {
    try {
        await fs.unlink(rutaArchivo);
        return true;
    } catch (error) {
        console.error("Error al eliminar el archivo:", error);
        return false;
    }
}


export {
    obtenerArchivo,
    verProtocoloItemPorId,
    verTodosProtocoloItems,
    verProtocoloItemsPorProtocoloId,
    crearProtocoloItem,
    actualizarProtocoloItem,
    eliminarProtocoloItem,
    actualizarPosiciones ,
    eliminarProtocoloItemPorId
};
