import mongoose from "mongoose";

const protocoloItemSchema = mongoose.Schema({
    protocolo: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Protocolo",
        required: true,
    },
    titulo: {
        type: String,
        required: true,
    },
    posicion: {
        type: Number,
        required: true
    },
    extension: {
        type: String,
        required: true,
    },
    mimetype:{
        type: String,
        required: true
    },
    ultimaActualizacion: {
        type: Date,
        required: false,
    },
    fechaSubida: {
        type: Date,
        required: true,
    },
    rutaArchivo: {
        type: String,
        required: false
    }
});

const ProtocoloItem = mongoose.model("ProtocoloItem", protocoloItemSchema);

export default ProtocoloItem;
