import mongoose from "mongoose";
const archivosCarpetaSchema = mongoose.Schema({
    carpeta: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Carpeta",
        required: true,
    },
    archivos: {
        type: [
            {
                titulo: {
                    type: String,
                    required: true,
                },
                rutaArchivo: {
                    type: String,
                    required: false
                },
                ultimaActualizacion: {
                    type: Date,
                    required: true,
                },
                fechaSubida: {
                    type: Date,
                    required: true,
                }
            },
        ],
        default: [],
    }
})

const ArchivosCarpeta = mongoose.model("ArchivosCarpeta", archivosCarpetaSchema);

export default ArchivosCarpeta;