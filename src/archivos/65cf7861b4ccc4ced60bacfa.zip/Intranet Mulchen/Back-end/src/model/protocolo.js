import mongoose from "mongoose";

const protocoloSchema = mongoose.Schema({
    nombre: {
        type: String,
        required: true,
    },
    abreviacion: {
        type: String,
        required: true
    },
    descripcion: {
        type: String,   
        required: false
    }
})

const Protocolo = mongoose.model("Protocolo", protocoloSchema);

export default Protocolo;