const PORT = 3000;
const TOKEN_DURATION = "1d";

export { TOKEN_DURATION, PORT };