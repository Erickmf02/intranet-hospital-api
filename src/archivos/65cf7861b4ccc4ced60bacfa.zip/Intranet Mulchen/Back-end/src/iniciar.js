import Rol from "./model/rol.js";
import Usuario from "./model/usuario.js";
import mongoose from "mongoose";
import bcrypt from "bcryptjs"
import Carpeta from "./model/carpeta.js";

async function iniciar(){
    try {
        let rolAdministrador = await Rol.findById("000000000000000000000001");
        if(!rolAdministrador){
            rolAdministrador = await Rol.create({
                _id: new mongoose.Types.ObjectId("000000000000000000000001"),
                nombre: "Administrador"
            })
        }
        let administrador = await Usuario.findOne({rut: "210396802"});
        if(!administrador){
            const hashedPassword = await bcrypt.hash("erick martinez", 8);
            administrador = await Usuario.create({
                nombre: "Erick Martínez",
                rut: "210396802",
                password: hashedPassword,
                roles: [
                    rolAdministrador
                ]
            })
        }
        let carpetaHome = await Carpeta.findById("100000000000000000000001");
        if(!carpetaHome){
            carpetaHome = await Carpeta.create({
                _id: new mongoose.Types.ObjectId("100000000000000000000001"),
                nombre: "Home",
                tipo: "carpetas"
            })
        }
    } catch (error) {
        console.log(error);
    }
}

export default iniciar;